// font faces, added to the page once
(function(){if(document.getElementById('dotdash-fonts'))return;var s=document.createElement('style');s.id='dotdash-fonts';s.textContent="@font-face{font-family:\"DD Mono\";src:url(/ui/ui-vue/src/assets/fonts/OverpassMono/static/OverpassMono-Regular.ttf) format(\"truetype\");}@font-face{font-family:\"DD Head\";src:url(/ui/ui-vue/src/assets/fonts/Overpass/static/Overpass-SemiBold.ttf) format(\"truetype\");}";document.head.appendChild(s);})();

// Figures in several looks, after phone lock-screen clock faces:
//
//   dot    NDot 55, the dot-matrix font (the original look)
//   grid   digits built from small square tiles, like the tiled clock face
//   block  the same shapes solid and wide, like the big clock face
//   wide   the lock-screen clock face ("520"): very wide, thick bars, thin
//          slits between them, outer corners rounded. Not a 3x5 grid of
//          equal cells - the rows are bar / slit / bar / slit / bar
//   ntype      NType82 Mono - every figure the same width, so live numbers
//              don't shuffle sideways as they change (the default)
//   ntypehead  NType82 Headline, the display face
//   led    the same shapes in big round dots, like the dotted clock face -
//          the NDot feel, but with dots large enough to read at a glance
//
// grid and block are drawn, not typeset: each digit is a 3x5 bitmap of
// strokes, so no font file is needed and they read at any size.
//
// root.DOT_STYLE.digits picks the look for every widget; dotNum() draws.

(function (root) {
  "use strict";

  root.DOT_STYLE = root.DOT_STYLE || { digits: "ntype", gauge: "line" };
  // typeset faces: which font, and how big next to NDot for the same height
  var TYPESET = { dot: ["dot", 1], ntype: ["mono", 1.02], ntypehead: ["head", 1.0] };

  var G = {
    "0": ["111", "101", "101", "101", "111"],
    "1": ["110", "010", "010", "010", "111"],
    "2": ["111", "001", "111", "100", "111"],
    "3": ["111", "001", "111", "001", "111"],
    "4": ["101", "101", "111", "001", "001"],
    "5": ["111", "100", "111", "001", "111"],
    "6": ["111", "100", "111", "101", "111"],
    "7": ["111", "001", "001", "001", "001"],
    "8": ["111", "101", "111", "101", "111"],
    "9": ["111", "101", "111", "001", "111"],
    "-": ["000", "000", "111", "000", "000"],
    ".": ["0", "0", "0", "0", "1"],
    " ": ["0", "0", "0", "0", "0"]
  };

  // the wide face: its own patterns (0 has a slit, not a hole), row heights
  // and column widths, as shares of the digit height
  var WIDE = {
    "0": ["111", "111", "101", "111", "111"],
    "1": ["110", "010", "010", "010", "111"],
    "2": ["111", "001", "111", "100", "111"],
    "3": ["111", "001", "111", "001", "111"],
    "4": ["101", "101", "111", "001", "001"],
    "5": ["111", "100", "111", "001", "111"],
    "6": ["111", "100", "111", "101", "111"],
    "7": ["111", "001", "001", "001", "001"],
    "8": ["111", "101", "111", "101", "111"],
    "9": ["111", "101", "111", "001", "111"],
    "-": ["000", "000", "111", "000", "000"],
    ".": ["0", "0", "0", "0", "1"],
    " ": ["0", "0", "0", "0", "0"]
  };
  var WROWS = [0.3, 0.12, 0.16, 0.12, 0.3];
  var WCOLS = [0.27, 0.62, 0.27];             // a glyph is ~1.16 x its height
  function wideCols(g) { return g[0].length === 1 ? [0.27] : WCOLS; }
  function wideW(g, h) { return wideCols(g).reduce(function (a, b) { return a + b; }, 0) * h; }

  function drawWide(c, s, x0, y, h, col) {
    var gap = h * 0.16, y0 = y - h / 2, rad = h * 0.13;
    c.fillStyle = col;
    for (var i = 0; i < s.length; i++) {
      var g = WIDE[s[i]] || WIDE[" "], cols = wideCols(g);
      var cy = y0;
      for (var r = 0; r < 5; r++) {
        var rh = WROWS[r] * h, cx = x0;
        for (var k = 0; k < cols.length; k++) {
          var cw = cols[k] * h;
          if (g[r][k] === "1") {
            var onp = function (rr2, kk) { return rr2 >= 0 && rr2 < 5 && kk >= 0 && kk < cols.length && g[rr2][kk] === "1"; };
            var tl = !onp(r - 1, k) && !onp(r, k - 1), tr = !onp(r - 1, k) && !onp(r, k + 1);
            var bl = !onp(r + 1, k) && !onp(r, k - 1), br = !onp(r + 1, k) && !onp(r, k + 1);
            var rr = Math.min(rad, rh, cw);
            c.beginPath();
            if (c.roundRect) c.roundRect(cx - 0.3, cy - 0.3, cw + 0.6, rh + 0.6, [tl ? rr : 0, tr ? rr : 0, br ? rr : 0, bl ? rr : 0]);
            else c.rect(cx - 0.3, cy - 0.3, cw + 0.6, rh + 0.6);
            c.fill();
          }
          cx += cw;
        }
        cy += rh;
      }
      x0 += wideW(g, h) + (i < s.length - 1 ? gap : 0);
    }
  }
  function measureWide(s, h) {
    var w = 0;
    for (var i = 0; i < s.length; i++) w += wideW(WIDE[s[i]] || WIDE[" "], h) + (i < s.length - 1 ? h * 0.16 : 0);
    return w;
  }

  // width of one glyph cell, as a share of the digit height
  function cellW(style) { return style === "block" ? 0.3 : 0.26; }
  function on(g, r, k) { return r >= 0 && r < 5 && k >= 0 && k < g[0].length && g[r][k] === "1"; }

  function measure(s, h, style) {
    if (style === "wide") return measureWide(s, h);
    var cw = h / 5 * (cellW(style) * 5), gap = cw * 0.55, w = 0;
    for (var i = 0; i < s.length; i++) {
      var g = G[s[i]] || G[" "];
      w += g[0].length * cw + (i < s.length - 1 ? gap : 0);
    }
    return w;
  }

  function draw(c, s, x, y, h, style, col, align) {
    if (style === "wide") {
      var ww = measureWide(s, h);
      drawWide(c, s, align === "right" ? x - ww : align === "left" ? x : x - ww / 2, y, h, col);
      return;
    }
    var cw = h / 5 * (cellW(style) * 5), ch = h / 5, gap = cw * 0.55;
    var w = measure(s, h, style);
    var x0 = align === "right" ? x - w : align === "left" ? x : x - w / 2;
    var y0 = y - h / 2;
    c.fillStyle = col;
    for (var i = 0; i < s.length; i++) {
      var g = G[s[i]] || G[" "];
      for (var r = 0; r < 5; r++)
        for (var k = 0; k < g[r].length; k++) {
          if (g[r][k] !== "1") continue;
          var cx = x0 + k * cw, cy = y0 + r * ch;
          if (style === "block") {
            // solid: cells overlap a hair so the stroke has no seams; the
            // outer corners of each stroke are rounded, like the clock face
            var rad = Math.min(cw, ch) * 0.32;
            var tl = !on(g, r - 1, k) && !on(g, r, k - 1), tr = !on(g, r - 1, k) && !on(g, r, k + 1);
            var bl = !on(g, r + 1, k) && !on(g, r, k - 1), br = !on(g, r + 1, k) && !on(g, r, k + 1);
            c.beginPath();
            if (c.roundRect) c.roundRect(cx - 0.25, cy - 0.25, cw + 0.5, ch + 0.5, [tl ? rad : 0, tr ? rad : 0, br ? rad : 0, bl ? rad : 0]);
            else c.rect(cx - 0.25, cy - 0.25, cw + 0.5, ch + 0.5);
            c.fill();
          } else if (style === "led") {
            // round dots, 2x2 per stroke cell
            var dr = Math.min(cw, ch) / 4 * 0.86;
            for (var a2 = 0; a2 < 2; a2++)
              for (var b2 = 0; b2 < 2; b2++) {
                c.beginPath(); c.arc(cx + (a2 + 0.5) * cw / 2, cy + (b2 + 0.5) * ch / 2, dr, 0, 6.2832); c.fill();
              }
          } else {
            // tiled: each stroke cell is 2x2 tiles with thin gaps
            var t = Math.max(0.6, Math.min(cw, ch) * 0.07);
            for (var a = 0; a < 2; a++)
              for (var b = 0; b < 2; b++)
                c.fillRect(cx + a * cw / 2 + t / 2, cy + b * ch / 2 + t / 2, cw / 2 - t, ch / 2 - t);
          }
        }
      x0 += g[0].length * cw + gap;
    }
  }

  // size is the font size the caller would have given NDot; digits come out
  // the same height either way, so layouts don't move when the style changes.
  // A trailing unit ("92°", "42%") is set in the mono font after the figures.
  function split(s) {
    var m = /^([0-9.\- ]+)(\D*)$/.exec(s);
    return m ? [m[1], m[2]] : null;
  }
  root.dotNumWidth = function (c, s, size, fontFn) {
    var style = root.DOT_STYLE.digits, p = split(String(s)), ts = TYPESET[style];
    if (ts || !p) { ts = ts || TYPESET.dot; c.font = fontFn(ts[0], size * ts[1]); return c.measureText(String(s)).width; }
    c.font = fontFn("mono", size * 0.5);
    return measure(p[0], size * 0.72, style) + (p[1] ? size * 0.08 + c.measureText(p[1]).width : 0);
  };
  root.dotNum = function (c, s, x, y, size, col, align, fontFn) {
    var style = root.DOT_STYLE.digits;
    s = String(s);
    var p = split(s), ts = TYPESET[style];
    align = align || "center";
    if (ts || !p) {
      ts = ts || TYPESET.dot;
      c.font = fontFn(ts[0], size * ts[1]); c.fillStyle = col;
      c.textAlign = align; c.textBaseline = "middle";
      c.fillText(s, x, y);
      return;
    }
    var h = size * 0.72, w = root.dotNumWidth(c, s, size, fontFn);
    var x0 = align === "right" ? x - w : align === "left" ? x : x - w / 2;
    draw(c, p[0], x0, y, h, style, col, "left");
    if (p[1]) {
      c.font = fontFn("mono", size * 0.5); c.fillStyle = col;
      c.textAlign = "left"; c.textBaseline = "top";
      c.fillText(p[1], x0 + measure(p[0], h, style) + size * 0.08, y - h / 2);
    }
  };
  // the same with a dark outline, for drawing straight over the game
  root.dotNumOutlined = function (c, s, x, y, size, col, align, fontFn, lw) {
    var ts = TYPESET[root.DOT_STYLE.digits];
    if (ts || !split(String(s))) {
      ts = ts || TYPESET.dot;
      c.font = fontFn(ts[0], size * ts[1]); c.textAlign = align || "center"; c.textBaseline = "middle";
      c.lineJoin = "round"; c.lineWidth = lw; c.strokeStyle = "rgba(0,0,0,0.85)";
      c.strokeText(String(s), x, y); c.fillStyle = col; c.fillText(String(s), x, y);
      return;
    }
    var o = lw * 0.45;
    [[-o, 0], [o, 0], [0, -o], [0, o], [-o, -o], [o, o], [-o, o], [o, -o]].forEach(function (d) {
      root.dotNum(c, s, x + d[0], y + d[1], size, "rgba(0,0,0,0.85)", align, fontFn);
    });
    root.dotNum(c, s, x, y, size, col, align, fontFn);
  };

  // ---- rev gauges as one thick continuous line ------------------------------
  // The fill fades in from the start, so the eye goes to where the revs are;
  // a short needle across the line marks the exact point. The redline is a
  // dim red stretch of the track, and turns bright as the revs reach it.
  var RED = "#D71920", TRACK = "#1b1b1b", TRACKRED = "#3a1013";

  // The fade is mixed into the track colour, not drawn with transparency: the
  // arc is many short pieces that overlap a hair, and with alpha every
  // overlap came out darker - a row of little squares along the gauge.
  // Opaque pieces overlap invisibly.
  function mix(c0, c1, t) {
    return "rgb(" + Math.round(c0[0] + (c1[0] - c0[0]) * t) + "," + Math.round(c0[1] + (c1[1] - c0[1]) * t) +
           "," + Math.round(c0[2] + (c1[2] - c0[2]) * t) + ")";
  }
  var T_RGB = [27, 27, 27], W_RGB = [255, 255, 255], R_RGB = [215, 25, 32], G_RGB = [177, 179, 179];
  function fadeCol(f, frac, red, shift, blink) {
    if (shift) return blink ? RED : "#7a0f13";
    var a = 0.16 + 0.84 * Math.pow(frac > 0 ? f / frac : 1, 1.6);   // faint at the start, full at the needle
    return mix(T_RGB, red ? R_RGB : W_RGB, a);
  }

  // Stroke the arc between fractions lo..hi of the sweep a0..a1, coloured by
  // colorAt(f). With createConicGradient it is one stroke and perfectly
  // smooth. Without it, pieces about 2 px long - short arcs at low revs used
  // to get a dozen pieces anyway, and the fade showed as steps.
  function fadeArc(c, cx, cy, rad, lw, a0, a1, lo, hi, colorAt) {
    if (hi - lo < 0.0005) return;
    var sweep = a1 - a0;
    c.lineWidth = lw; c.lineCap = "butt";
    if (c.createConicGradient) {
      var g = c.createConicGradient(a0, cx, cy), n = 24;
      for (var i = 0; i <= n; i++) {
        var f = lo + (hi - lo) * i / n;
        g.addColorStop(Math.min(1, Math.max(0, (f * sweep) / TAU2)), colorAt(f));
      }
      c.beginPath(); c.arc(cx, cy, rad, a0 + sweep * lo, a0 + sweep * hi);
      c.strokeStyle = g; c.stroke();
      return;
    }
    var len = rad * sweep * (hi - lo), m = Math.max(4, Math.ceil(len / 2)), step = (hi - lo) / m;
    for (var k = 0; k < m; k++) {
      // overlap each piece by a fixed pixel: a share of a 2 px piece is less
      // than the anti-aliased edge, and the seams showed as dips
      var f0 = lo + k * step, over = 1.2 / (rad * sweep);
      var f1 = Math.min(hi, f0 + step + over);
      c.beginPath(); c.arc(cx, cy, rad, a0 + sweep * f0, a0 + sweep * f1);
      c.strokeStyle = colorAt(f0 + step / 2); c.stroke();
    }
  }
  var TAU2 = Math.PI * 2;

  root.dotGaugeArc = function (c, cx, cy, rad, lw, a0, a1, frac, redFrom, shift, blink) {
    c.lineCap = "butt"; c.lineWidth = lw;
    c.beginPath(); c.arc(cx, cy, rad, a0, a0 + (a1 - a0) * redFrom); c.strokeStyle = TRACK; c.stroke();
    if (redFrom < 1) { c.beginPath(); c.arc(cx, cy, rad, a0 + (a1 - a0) * redFrom, a1); c.strokeStyle = TRACKRED; c.stroke(); }
    if (frac > 0.002) {
      // white up to the redline, red after it - two strokes, so the change is sharp
      fadeArc(c, cx, cy, rad, lw, a0, a1, 0, Math.min(frac, redFrom),
              function (f) { return fadeCol(f, frac, false, shift, blink); });
      if (frac > redFrom)
        fadeArc(c, cx, cy, rad, lw, a0, a1, redFrom, frac,
                function (f) { return fadeCol(f, frac, true, shift, blink); });
    }
    // the needle: a short bar across the line, only where the revs are
    var a = a0 + (a1 - a0) * frac, ca = Math.cos(a), sa = Math.sin(a);
    var r0 = rad - lw * 1.05, r1 = rad + lw * 1.05;
    c.lineCap = "round";
    c.beginPath(); c.moveTo(cx + ca * r0, cy + sa * r0); c.lineTo(cx + ca * r1, cy + sa * r1);
    c.strokeStyle = "rgba(0,0,0,0.9)"; c.lineWidth = Math.max(4, lw * 0.5); c.stroke();
    c.beginPath(); c.moveTo(cx + ca * r0, cy + sa * r0); c.lineTo(cx + ca * r1, cy + sa * r1);
    c.strokeStyle = shift || frac >= redFrom ? RED : "#ffffff"; c.lineWidth = Math.max(2, lw * 0.26); c.stroke();
    c.lineCap = "butt";
  };

  // like dotGaugeArc, but filled between `from` and `to` (both 0..1 of the
  // sweep) - for the boost gauge, where the fill runs from 0 bar either way
  root.dotGaugeArcFrom = function (c, cx, cy, rad, lw, a0, a1, from, to, redFrom, vacuum, blink, peak) {
    c.lineCap = "butt"; c.lineWidth = lw;
    c.beginPath(); c.arc(cx, cy, rad, a0, a0 + (a1 - a0) * redFrom); c.strokeStyle = TRACK; c.stroke();
    if (redFrom < 1) { c.beginPath(); c.arc(cx, cy, rad, a0 + (a1 - a0) * redFrom, a1); c.strokeStyle = TRACKRED; c.stroke(); }
    var lo = Math.min(from, to), hi = Math.max(from, to), span = hi - lo;
    if (span > 0.002) {
      // fade from the zero point out to the needle
      var fadeAt = function (f) {
        var t = vacuum ? (hi - f) / span : (f - lo) / span;
        return 0.16 + 0.84 * Math.pow(Math.max(0, Math.min(1, t)), 1.6);
      };
      if (vacuum) fadeArc(c, cx, cy, rad, lw, a0, a1, lo, hi, function (f) { return mix(T_RGB, G_RGB, fadeAt(f) * 0.8); });
      else {
        fadeArc(c, cx, cy, rad, lw, a0, a1, lo, Math.min(hi, redFrom), function (f) { return mix(T_RGB, W_RGB, fadeAt(f)); });
        if (hi > redFrom) fadeArc(c, cx, cy, rad, lw, a0, a1, Math.max(lo, redFrom), hi, function (f) { return mix(T_RGB, R_RGB, fadeAt(f)); });
      }
    }
    // zero mark: a thin tick across the track
    var az = a0 + (a1 - a0) * from;
    c.beginPath(); c.moveTo(cx + Math.cos(az) * (rad - lw * 0.7), cy + Math.sin(az) * (rad - lw * 0.7));
    c.lineTo(cx + Math.cos(az) * (rad + lw * 0.7), cy + Math.sin(az) * (rad + lw * 0.7));
    c.strokeStyle = "#555"; c.lineWidth = Math.max(1, lw * 0.12); c.stroke();
    // peak hold: a small red tick
    if (peak !== null && peak !== undefined && peak > from + 0.01) {
      var ap = a0 + (a1 - a0) * peak;
      c.beginPath(); c.moveTo(cx + Math.cos(ap) * (rad - lw * 0.5), cy + Math.sin(ap) * (rad - lw * 0.5));
      c.lineTo(cx + Math.cos(ap) * (rad + lw * 0.5), cy + Math.sin(ap) * (rad + lw * 0.5));
      c.strokeStyle = RED; c.lineWidth = Math.max(1.5, lw * 0.2); c.stroke();
    }
    // the needle
    var an = a0 + (a1 - a0) * to, ca = Math.cos(an), sa = Math.sin(an);
    var r0 = rad - lw * 1.05, r1 = rad + lw * 1.05;
    c.lineCap = "round";
    c.beginPath(); c.moveTo(cx + ca * r0, cy + sa * r0); c.lineTo(cx + ca * r1, cy + sa * r1);
    c.strokeStyle = "rgba(0,0,0,0.9)"; c.lineWidth = Math.max(4, lw * 0.5); c.stroke();
    c.beginPath(); c.moveTo(cx + ca * r0, cy + sa * r0); c.lineTo(cx + ca * r1, cy + sa * r1);
    c.strokeStyle = !vacuum && to >= redFrom ? (blink ? RED : "#ff5a5f") : "#ffffff"; c.lineWidth = Math.max(2, lw * 0.26); c.stroke();
    c.lineCap = "butt";
  };

  root.dotGaugeBar = function (c, x0, x1, y, h, frac, redFrom, shift, blink) {
    var W = x1 - x0, xr = x0 + W * redFrom, xv = x0 + W * frac, r = Math.min(3, h * 0.2);
    var box = function (xa, xb, col) {
      if (xb - xa < 0.5) return;
      c.beginPath();
      if (c.roundRect) c.roundRect(xa, y - h / 2, xb - xa, h, r); else c.rect(xa, y - h / 2, xb - xa, h);
      c.fillStyle = col; c.fill();
    };
    box(x0, xr, TRACK); box(xr, x1, TRACKRED);
    if (frac > 0.002) {
      if (shift) box(x0, xv, blink ? RED : "#7a0f13");
      else {
        var g = c.createLinearGradient(x0, 0, Math.max(x0 + 1, xv), 0);
        g.addColorStop(0, mix(T_RGB, W_RGB, 0.16)); g.addColorStop(1, "#ffffff");
        box(x0, Math.min(xv, xr), g);
        if (xv > xr) {
          var g2 = c.createLinearGradient(xr, 0, Math.max(xr + 1, xv), 0);
          g2.addColorStop(0, mix(T_RGB, R_RGB, 0.55)); g2.addColorStop(1, RED);
          box(xr, xv, g2);
        }
      }
    }
    // the needle: a short upright bar, only where the revs are
    var nh = h * 2.1, nw = Math.max(2, h * 0.22);
    c.fillStyle = "rgba(0,0,0,0.9)"; c.fillRect(xv - nw / 2 - 1.5, y - nh / 2 - 1.5, nw + 3, nh + 3);
    c.fillStyle = shift || frac >= redFrom ? RED : "#ffffff"; c.fillRect(xv - nw / 2, y - nh / 2, nw, nh);
  };
})(typeof window !== "undefined" ? window : this);

// BeamNG streams -> the plain numbers every DotDash widget draws from.
// One place, so the tacho, the boost gauge and the rest can't disagree about
// what "gear" or "fuel" means.

(function (root) {
  "use strict";
  var GEARS_A = ['P', 'R', 'N', 'D', '2', '1'];

  function gearOf(e, info) {
    if (info && info[13] === 'manual') {
      var g = info[5];
      return g > 0 ? String(g) : g < 0 ? 'R' : 'N';
    }
    // electrics.gear is what the gearbox itself calls the gear:
    //   automatic / DCT  "P" "R" "N" "D", "S3" (sport, 3rd), "M4" (manual mode, 4th), "1" "2"
    //   sequential       a plain number (2), 0 for neutral, -1 for reverse
    if (typeof e.gear === 'string' && e.gear.length) return e.gear;
    if (typeof e.gear === 'number' && isFinite(e.gear)) return e.gear > 0 ? String(e.gear) : e.gear < 0 ? 'R' : 'N';
    if (e.gear_A !== undefined) return GEARS_A[Math.round(e.gear_A * 5)] || 'D';
    if (info && info[5] !== undefined) {
      var n = info[5];
      return n > 0 ? String(n) : n < 0 ? 'R' : 'N';
    }
    return 'N';
  }

  // The player picks units in the game's options (km/h or mph, bar / kPa / psi,
  // °C / °F). UiUnits is the game's own converter; without it (the browser
  // preview) we fall back to metric.
  function pconv(kpa) {
    var r = root.UiUnits && UiUnits.pressure ? UiUnits.pressure(kpa) : null;
    return r && isFinite(r.val) ? r : { val: kpa / 100, unit: 'Bar' };
  }
  function tconv(c) {
    var r = root.UiUnits && UiUnits.temperature ? UiUnits.temperature(c) : null;
    return r && isFinite(r.val) ? r : { val: c, unit: '°C' };
  }
  function tempText(c) {
    if (c === undefined || c === null || !isFinite(c)) return undefined;
    var r = tconv(c);
    return Math.round(r.val) + (r.unit === 'K' ? 'K' : '°');
  }
  root.dotPressure = pconv;

  // what each widget subscribes to; boost only when the boost gauge is up
  root.DOT_STREAMS = {
    base: ['electrics', 'engineInfo'],
    g: ['sensors'],
    boost: ['forcedInductionInfo']
  };

  root.dotData = function (s) {
    var e = s.electrics;
    if (!e) return null;
    var info = s.engineInfo;
    var speed = e.wheelspeed !== undefined ? e.wheelspeed : (e.airspeed || 0);

    var text, unit;
    if (root.UiUnits && UiUnits.speed) {
      var u = UiUnits.speed(speed);
      if (u && !isNaN(u.val)) { text = String(Math.round(u.val)); unit = u.unit; }
    }

    var gx = 0, gy = 0;
    if (s.sensors && s.sensors.gravity) {
      var gr = -s.sensors.gravity;
      gx = (s.sensors.gx2 !== undefined ? s.sensors.gx2 : s.sensors.gx || 0) / gr;
      gy = (s.sensors.gy2 !== undefined ? s.sensors.gy2 : s.sensors.gy || 0) / gr;
    }

    var boostKpa, maxBoostKpa;
    var fi = s.forcedInductionInfo;
    if (fi && isFinite(fi.boost) && isFinite(fi.maxBoost)) {
      boostKpa = fi.boost;               // the stream is in kPa whatever the UI shows
      maxBoostKpa = fi.maxBoost;
    }

    var rpm = e.rpmTacho !== undefined ? e.rpmTacho : (e.rpm !== undefined ? e.rpm : (info ? info[4] : 0));
    var idle = info ? info[0] : 800;
    return {
      speed: speed, speedText: text, speedUnit: unit,
      rpm: rpm, maxRpm: info ? info[1] : 0, idleRpm: idle,
      gear: gearOf(e, info),
      // for the gear row: what the box has and where it is
      gearbox: info ? info[13] : undefined,
      gearIndex: info ? info[5] : 0,
      gearsF: info && info[6] > 0 ? info[6] : 0,
      gearsR: info && info[7] > 0 ? info[7] : 0,
      parkingbrake: e.parkingbrake || 0,
      throttle: e.throttle || 0, brake: e.brake || 0, clutch: e.clutch || 0,
      gx: gx, gy: gy,
      water: e.watertemp, oil: e.oiltemp,              // °C, for the warning thresholds
      waterText: tempText(e.watertemp), oilText: tempText(e.oiltemp),
      fuel: info && info[12] ? info[11] / info[12] : undefined,
      abs: !!e.absActive, tcs: !!e.tcsActive,
      handbrake: (e.parkingbrake || 0) > 0.5,
      signalL: !!e.signal_L, signalR: !!e.signal_R,
      highbeam: !!e.highbeam, lowbeam: !!e.lowbeam, fog: (e.fog || 0) > 0,
      lowfuel: !!e.lowfuel,
      ignition: e.ignitionLevel !== undefined ? e.ignitionLevel : (e.ignition ? 2 : 0),
      running: e.engineRunning !== undefined ? !!e.engineRunning : rpm > idle * 0.5,
      boostKpa: boostKpa, maxBoostKpa: maxBoostKpa
    };
  };
})(typeof window !== "undefined" ? window : this);

// DotDash widgets - one canvas each, so each can be its own BeamNG app and be
// placed, sized and hidden on its own. They all take the object streams.js
// makes (dotData) and redraw only when it arrives.
//
//   DotTacho     rpm and speed in one round gauge, gear, fuel, water, warnings
//   DotBoost     turbo pressure, bar, with vacuum and a peak hold
//   DotGMeter    lateral / longitudinal G with a trail and peak
//   DotPedals    clutch, brake, throttle, handbrake as thick bars with %
//   DotPedalsClear  the same with no background and the % inside the bars
//   DotRpm       the rpm glyph row on its own, with a shift light
//   DotGearRing  the gear in a circle with the revs round it
//   DotGear      the current gear, big, with the gearbox type and 4/6
//   DotGears     every gear of the box on a row, current lit, next one red at the limit
//   DotInfo      water, oil, fuel as readouts with dot bars
//   DotTimer     0-100 and 0-200 km/h, session bests
//   DotStartStop the engine button - drawn here, pressed in the adapter

(function (root) {
  "use strict";

  var WHITE = "#ffffff", RED = "#D71920", DIM = "#232323", DIMRED = "#2a1112",
      MUTE = "#6b6b6b", GREY = "#B1B3B3", CARD = "rgba(0,0,0,0.84)";
  var TAU = Math.PI * 2;
  var A0 = 0.75 * Math.PI, A1 = 2.25 * Math.PI;      // gauges sweep 270°, open at the bottom

  function font(kind, px) {
    // a private build can embed its own faces; the public one falls back to
    // Overpass / Overpass Mono, which ship with BeamNG itself (see build.py)
    var fam = { dot: "'NDot 55', 'DD Mono', Consolas, monospace",
                head: "'NType82 Headline', 'DD Head', 'Segoe UI', sans-serif",
                mono: "'NType82 Mono', 'DD Mono', Consolas, monospace" }[kind];
    return Math.max(8, px) + "px " + fam;
  }
  function dot(c, x, y, r, col) { c.fillStyle = col; c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill(); }
  function rr(c, x, y, w, h, r) {
    c.beginPath();
    c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r);
    c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath();
  }
  function text(c, s, x, y, f, col, align, base) {
    c.font = f; c.fillStyle = col; c.textAlign = align || "center"; c.textBaseline = base || "middle";
    c.fillText(s, x, y);
  }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }

  // A gear as the gearbox names it. "S3" / "M4" (sport / manual mode of an
  // automatic or DCT) get the number big and the mode letter small beside it;
  // everything else - P R N D, 1-9, R2 - is set as it is.
  function gearText(c, g, x, y, size, col) {
    g = g === undefined || g === null ? "N" : String(g);
    var m = /^([SM])(\d+)$/.exec(g);
    if (!m) { text(c, g, x, y, font("head", size * (g.length > 1 ? 0.78 : 1)), col); return; }
    c.font = font("head", size); var wn = c.measureText(m[2]).width;
    c.font = font("mono", size * 0.42); var wl = c.measureText(m[1]).width;
    var gap = size * 0.05, x0 = x - (wn + gap + wl) / 2;
    text(c, m[1], x0 + wl / 2, y - size * 0.22, font("mono", size * 0.42), m[1] === "S" ? RED : GREY);
    text(c, m[2], x0 + wl + gap + wn / 2, y, font("head", size), col);
  }
  root.dotGearText = gearText;

  // The dashboard lamp symbols, r = half their height. The lamp body is a
  // "D" facing right; its beams go out to the left:
  //   lo   beams slanting down        hi   beams straight
  //   fog  beams slanting down, crossed by a wavy line
  function lamp(c, kind, x, y, r, col) {
    var lw = Math.max(1.2, r * 0.2);
    c.strokeStyle = col; c.lineWidth = lw; c.lineCap = "round"; c.lineJoin = "round";
    var bx = x + r * 0.15;                                  // flat side of the lamp
    c.beginPath();
    c.moveTo(bx, y - r * 0.85);
    c.bezierCurveTo(bx + r * 1.25, y - r * 0.85, bx + r * 1.25, y + r * 0.85, bx, y + r * 0.85);
    c.closePath(); c.stroke();
    var x0 = bx - r * 0.25, len = r * 0.95;
    [-0.6, -0.2, 0.2, 0.6].forEach(function (k) {
      var yy = y + k * r;
      c.beginPath(); c.moveTo(x0, yy);
      c.lineTo(x0 - len, kind === "hi" ? yy : yy + r * 0.38);
      c.stroke();
    });
    if (kind === "fog") {                                   // the wavy line through the beams
      var wx = x0 - len * 0.5;
      c.beginPath(); c.moveTo(wx, y - r);
      c.bezierCurveTo(wx + r * 0.35, y - r * 0.5, wx - r * 0.35, y + r * 0.0, wx, y + r * 0.35);
      c.bezierCurveTo(wx + r * 0.35, y + r * 0.7, wx, y + r * 1.0, wx, y + r * 1.15);
      c.stroke();
    }
    c.lineCap = "butt"; c.lineJoin = "miter";
  }
  // figures in the chosen look (numfont.js): NDot, tiled grid or solid block
  function num(c, s, x, y, size, col, align) { root.dotNum(c, s, x, y, size, col, align, font); }
  function lineGauges() { return (root.DOT_STYLE || {}).gauge !== "dots"; }

  // ---- the shared part: canvas sizing, redraw on data ----------------------
  function Base(canvas) {
    this.cv = canvas;
    this.ctx = canvas.getContext("2d");
    this.data = null;
    this.resize();
  }
  Base.prototype.resize = function () {
    var r = this.cv.getBoundingClientRect(), dpr = root.devicePixelRatio || 1;
    this.W = Math.max(40, r.width); this.H = Math.max(40, r.height); this.dpr = dpr;
    this.cv.width = Math.round(this.W * dpr); this.cv.height = Math.round(this.H * dpr);
    this.cache = null;
    if (this.data) this.draw();
  };
  Base.prototype.update = function (d) {
    if (!d) return;
    var now = performance.now();
    this.data = d;
    if (this.tick) this.tick(d, now);
    this.draw(now);
  };
  Base.prototype.draw = function (now) {
    var c = this.ctx;
    c.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    c.clearRect(0, 0, this.W, this.H);
    this.paint(c, this.W, this.H, now || performance.now(), this.data);
  };
  // round card centred in the canvas; returns centre and radius
  Base.prototype.disc = function (c) {
    var S = Math.min(this.W, this.H), cx = this.W / 2, cy = this.H / 2;
    c.beginPath(); c.arc(cx, cy, S / 2, 0, TAU);
    c.fillStyle = CARD; c.fill();
    return { S: S, cx: cx, cy: cy, R: S / 2 };
  };
  Base.prototype.card = function (c) {
    rr(c, 0, 0, this.W, this.H, Math.min(22, Math.min(this.W, this.H) * 0.16));
    c.fillStyle = CARD; c.fill();
  };
  function make(paint, tick, init) {
    function W(canvas) { if (init) init.call(this); Base.call(this, canvas); }
    W.prototype = Object.create(Base.prototype);
    W.prototype.paint = paint;
    if (tick) W.prototype.tick = tick;
    return W;
  }

  // dots along the gauge arc; lit(i, frac) -> colour
  function arcDots(c, cx, cy, rad, n, size, colour) {
    for (var i = 0; i < n; i++) {
      var f = n === 1 ? 0 : i / (n - 1), a = A0 + (A1 - A0) * f;
      dot(c, cx + Math.cos(a) * rad, cy + Math.sin(a) * rad, size, colour(i, f));
    }
  }

  // ---- tacho: rpm round the outside, speed in the middle ------------------
  root.DotTacho = make(function (c, W, H, now, d) {
    var g = this.disc(c), S = g.S, cx = g.cx, cy = g.cy, R = g.R;
    var maxRpm = d.maxRpm > 0 ? d.maxRpm : 7000;
    var maxK = Math.ceil(maxRpm / 1000), scale = maxK * 1000;
    var frac = clamp((d.rpm || 0) / scale, 0, 1);
    var redFrom = maxRpm * 0.9 / scale;
    var shift = (d.rpm || 0) >= maxRpm * 0.95;
    var blink = shift && Math.floor(now / 70) % 2;
    var n = clamp(maxK * 5, 30, 60);

    if (lineGauges()) root.dotGaugeArc(c, cx, cy, R * 0.86, Math.max(4, S * 0.045), A0, A1, frac, redFrom, shift, blink);
    else arcDots(c, cx, cy, R * 0.86, n, Math.max(2, S * 0.016), function (i, f) {
      var on = f <= frac + 1e-6 && frac > 0, red = f >= redFrom;
      if (on) return shift ? (blink ? RED : "#5a0b0e") : red ? RED : WHITE;
      return red ? DIMRED : DIM;
    });
    for (var k = 0; k <= maxK; k++) {
      var a = A0 + (A1 - A0) * (k / maxK);
      text(c, String(k), cx + Math.cos(a) * R * 0.71, cy + Math.sin(a) * R * 0.71,
           font("mono", S * 0.055), k * 1000 >= maxRpm * 0.9 ? RED : GREY);
    }

    // speed, unit, gear - stacked in the middle, clear of the scale ends
    var spd = d.speedText !== undefined ? d.speedText : String(Math.round((d.speed || 0) * 3.6));
    num(c, spd, cx, cy - S * 0.06, S * 0.2, WHITE);
    text(c, (d.speedUnit || "km/h").toUpperCase(), cx, cy + S * 0.065, font("mono", S * 0.04), GREY);
    var gy = cy + S * 0.18;
    gearText(c, d.gear, cx, gy, S * 0.12, shift ? RED : WHITE);
    text(c, "×1000 RPM", cx, cy - S * 0.27, font("mono", S * 0.032), MUTE);

    // turn signals either side of the gear
    var sx = S * 0.12, t = S * 0.028;
    var SIGNAL = "#FFC700";                     // turn signals in yellow
    c.fillStyle = d.signalL ? SIGNAL : DIM;
    c.beginPath(); c.moveTo(cx - sx - t, gy); c.lineTo(cx - sx + t * 0.6, gy - t); c.lineTo(cx - sx + t * 0.6, gy + t); c.fill();
    c.fillStyle = d.signalR ? SIGNAL : DIM;
    c.beginPath(); c.moveTo(cx + sx + t, gy); c.lineTo(cx + sx - t * 0.6, gy - t); c.lineTo(cx + sx - t * 0.6, gy + t); c.fill();

    // a row of warning marks, lit when active
    var fs = S * 0.034, gap = S * 0.03;
    // a row of warning marks, lit when active. Text, or a drawn lamp symbol
    // ("lamp:lo" / "lamp:hi" / "lamp:fog") the size of a capital letter.
    var row = function (items, y) {
      c.font = font("mono", fs);
      var wOf = function (m2) { return m2[0].indexOf("lamp:") === 0 ? fs * 1.55 : c.measureText(m2[0]).width; };
      var total = items.reduce(function (s2, m2) { return s2 + wOf(m2); }, 0) + gap * (items.length - 1);
      var x = cx - total / 2;
      items.forEach(function (m2) {
        var w2 = wOf(m2);
        if (m2[0].indexOf("lamp:") === 0) lamp(c, m2[0].slice(5), x + w2 / 2, y, fs * 0.62, m2[1]);
        else text(c, m2[0], x + w2 / 2, y, font("mono", fs), m2[1]);
        c.font = font("mono", fs);
        x += w2 + gap;
      });
    };
    // warnings on their own, centred under the gear
    row([["ABS", d.abs ? RED : "#333"], ["TCS", d.tcs ? RED : "#333"], ["P", d.handbrake ? RED : "#333"]], cy + S * 0.29);
    // water and fuel as readouts, red when they need you
    var hot = d.water !== undefined && d.water > 115, low = d.fuel !== undefined && d.fuel < 0.15;
    row([["H2O " + (d.waterText || (d.water === undefined ? "--" : Math.round(d.water) + "°")), hot ? RED : GREY],
         ["FUEL " + (d.fuel === undefined ? "--" : Math.round(d.fuel * 100) + "%"), low ? RED : GREY]], cy + S * 0.37);
    // the lamps last, at the bottom of the gap
    row([["lamp:lo", d.lowbeam ? WHITE : "#333"], ["lamp:fog", d.fog ? WHITE : "#333"],
         ["lamp:hi", d.highbeam ? WHITE : "#333"]], cy + S * 0.44);
  });

  // ---- boost: vacuum below zero in grey, boost above in white, red near max ----
  // In whatever pressure unit the player chose in the game (bar, kPa, psi,
  // inHg): the stream is kPa, root.dotPressure converts. The scale is rounded
  // to steps that read well in that unit.
  var STEP = { "Bar": 0.5, "PSI": 5, "kPa": 50, "in.Hg": 10 };
  root.DotBoost = make(function (c, W, H, now, d) {
    var g = this.disc(c), S = g.S, cx = g.cx, cy = g.cy, R = g.R;
    var conv = root.dotPressure || function (k) { return { val: k / 100, unit: "Bar" }; };
    var have = d.boostKpa !== undefined;
    var unit = conv(100).unit, step = STEP[unit] || 1, dec = unit === "Bar" ? 1 : 0;
    var hiK = Math.max(150, (d.maxBoostKpa || 150) * 1.1);
    var lo = conv(-100).val, hi = Math.ceil(conv(hiK).val / step) * step;
    var b = have ? clamp(conv(d.boostKpa).val, lo, hi) : 0;
    var maxB = conv(d.maxBoostKpa || hiK).val;
    var pos = function (v) { return (v - lo) / (hi - lo); };
    var z = pos(0), cur = pos(b), redFrom = pos(maxB * 0.85);
    this.peak = Math.max((this.peak || 0) - step * 0.004, b);
    if (this.unit !== unit) { this.peak = b; this.unit = unit; }   // units changed in the menu
    if (lineGauges()) {
      var blinkB = Math.floor(now / 90) % 2;
      root.dotGaugeArcFrom(c, cx, cy, R * 0.84, Math.max(4, S * 0.05), A0, A1, z, have ? cur : z, redFrom,
                           have && b < 0, blinkB, have ? pos(this.peak) : null);
    } else {
      arcDots(c, cx, cy, R * 0.84, 34, Math.max(2, S * 0.022), function (i, f) {
        var on = b >= 0 ? (f >= z - 1e-6 && f <= cur + 1e-6) : (f <= z + 1e-6 && f >= cur - 1e-6);
        if (!have) return DIM;
        if (on) return b < 0 ? MUTE : (f >= redFrom ? RED : WHITE);
        return f >= redFrom ? DIMRED : DIM;
      });
      if (have && this.peak > step * 0.1) {     // peak hold, just inside the ring
        var a = A0 + (A1 - A0) * pos(this.peak);
        dot(c, cx + Math.cos(a) * R * 0.7, cy + Math.sin(a) * R * 0.7, Math.max(2, S * 0.02), RED);
      }
    }
    [lo, 0, hi].forEach(function (v) {
      var a2 = A0 + (A1 - A0) * pos(v);
      text(c, v.toFixed(Math.abs(v) < 10 && v % 1 ? 1 : 0), cx + Math.cos(a2) * R * 0.62, cy + Math.sin(a2) * R * 0.62,
           font("mono", S * 0.06), MUTE);
    });
    num(c, have ? b.toFixed(dec) : "--", cx, cy - S * 0.02, S * (dec ? 0.26 : 0.22),
        have && b >= maxB * 0.85 ? RED : WHITE);
    text(c, unit.toUpperCase(), cx, cy + S * 0.16, font("mono", S * 0.06), GREY);
    text(c, have ? "PK " + this.peak.toFixed(dec) : "NO TURBO", cx, cy + S * 0.36, font("mono", S * 0.05), MUTE);
  });

  // ---- G meter --------------------------------------------------------------
  root.DotGMeter = make(function (c, W, H, now, d) {
    var g = this.disc(c), S = g.S, cx = g.cx, cy = g.cy, R = g.R * 0.78, GMAX = 1.5;
    var step = Math.max(6, R / 7);
    for (var y = -R; y <= R + 0.1; y += step)
      for (var x = -R; x <= R + 0.1; x += step)
        if (x * x + y * y <= R * R)
          dot(c, cx + x, cy + y, Math.max(1.2, S * 0.007), (Math.abs(x) < 1 || Math.abs(y) < 1) ? "#3a3a3a" : "#1c1c1c");
    c.strokeStyle = "#2a2a2a"; c.lineWidth = 1;
    [0.5, 1].forEach(function (k) { c.beginPath(); c.arc(cx, cy, R * k / GMAX, 0, TAU); c.stroke(); });
    var xy = function (p) {
      return [cx + clamp(p[0] / GMAX, -1, 1) * R, cy - clamp(p[1] / GMAX, -1, 1) * R];
    };
    this.trail.forEach(function (p, i, arr) {
      var q = xy(p); c.globalAlpha = (i + 1) / arr.length * 0.6; dot(c, q[0], q[1], Math.max(1.5, S * 0.01), WHITE);
    });
    c.globalAlpha = 1;
    var p = xy([d.gx || 0, d.gy || 0]);
    dot(c, p[0], p[1], Math.max(3, S * 0.035), RED);
    text(c, Math.hypot(d.gx || 0, d.gy || 0).toFixed(2) + "G", cx, cy + g.R * 0.88, font("mono", S * 0.055), WHITE);
    text(c, "PK " + this.peak.toFixed(2), cx, cy - g.R * 0.88, font("mono", S * 0.05), MUTE);
  }, function (d) {
    this.trail.push([d.gx || 0, d.gy || 0]);
    if (this.trail.length > 28) this.trail.shift();
    this.peak = Math.max(this.peak * 0.999, Math.hypot(d.gx || 0, d.gy || 0));
  }, function () { this.trail = []; this.peak = 0; });

  // ---- pedals: clutch, brake, throttle, handbrake - thick bars with 0-100% ----
  // One solid bar each, barely rounded, wide enough to read from the corner of
  // your eye.
  var YELLOW = "#FFC700";                       // N-yellow, from the brand palette

  // Text with a dark outline, for drawing straight over the game.
  function outlined(c, s, x, y, f, col, lw) {
    c.font = f; c.textAlign = "center"; c.textBaseline = "middle";
    c.lineJoin = "round"; c.lineWidth = lw; c.strokeStyle = "rgba(0,0,0,0.85)";
    c.strokeText(s, x, y);
    c.fillStyle = col; c.fillText(s, x, y);
  }

  // clear: no card, the % written inside each bar, outlines on the text so it
  // reads over sky and tarmac alike
  function pedals(clear) {
    return make(function (c, W, H, now, d) {
      if (!clear) this.card(c);
      var tcsBlink = d.tcs && Math.floor(now / 120) % 2;
      var cols = [
        ["CLU", d.clutch, GREY],
        ["BRK", d.brake, RED],
        ["THR", d.throttle, tcsBlink ? MUTE : WHITE],      // blinks while TCS cuts in
        ["HBK", d.parkingbrake, YELLOW]
      ];
      var pad = Math.min(W, H) * (clear ? 0.03 : 0.08), colW = (W - pad * 2) / cols.length;
      var top = clear ? H * 0.04 : H * 0.2, bottom = H * 0.84;
      var bw = colW * (clear ? 0.78 : 0.7);
      var fs = Math.min(colW * 0.3, H * 0.085);
      cols.forEach(function (col, j) {
        var x = pad + colW * (j + 0.5), v = clamp(col[1] || 0, 0, 1);
        var colour = (j === 1 && d.abs && Math.floor(now / 80) % 2) ? "#ff5a5f" : col[2];
        // one continuous bar: a dark track, filled from the bottom
        var rad = Math.min(3, bw * 0.06), hFull = bottom - top;
        rr(c, x - bw / 2, top, bw, hFull, rad);
        c.fillStyle = clear ? "rgba(20,20,20,0.55)" : DIM; c.fill();
        if (v > 0.002) {
          var hv = Math.max(rad * 2, hFull * v);
          rr(c, x - bw / 2, bottom - hv, bw, hv, rad);
          c.fillStyle = colour; c.fill();
        }
        var pct = String(Math.round(v * 100));
        if (clear) {
          // inside the bar, at its top like the stock pedals; outlined so it
          // reads on any fill
          var pf = Math.min(bw * 0.42, fs * 1.6);
          root.dotNumOutlined(c, pct, x, top + pf * 0.75, pf, WHITE, "center", font, Math.max(3, fs * 0.35));
          outlined(c, col[0], x, H * 0.93, font("mono", fs * 0.85), v > 0.005 ? col[2] : GREY, Math.max(2.5, fs * 0.3));
        } else {
          num(c, pct, x, H * 0.1, fs * 1.3, v > 0.005 ? WHITE : MUTE);
          text(c, col[0], x, H * 0.93, font("mono", fs * 0.8), v > 0.005 ? col[2] : MUTE);
        }
      });
    });
  }
  root.DotPedals = pedals(false);
  root.DotPedalsClear = pedals(true);

  // ---- gears: the whole box on one row, the one you're in lit --------------
  // Manual: R, N, 1..n from engineInfo (how many the gearbox really has).
  // Automatic: P R N D 2 1. Near the limiter the next gear lights red - shift.
  root.DotGears = make(function (c, W, H, now, d) {
    this.card(c);
    var items, cur;
    if (d.gearbox === "manual" && d.gearsF > 0) {
      items = ["R", "N"];
      for (var i = 1; i <= d.gearsF; i++) items.push(String(i));
      cur = d.gearIndex < 0 ? "R" : d.gearIndex === 0 ? "N" : String(d.gearIndex);
    } else {
      // automatic / DCT: the selector positions. In sport or manual mode the
      // S or M slot lights and carries the gear ("S3", "M4").
      items = ["P", "R", "N", "D", "S", "M"];
      cur = String(d.gear || "N");
      var mode = /^([SM])(\d+)$/.exec(cur);
      if (mode) { items[items.indexOf(mode[1])] = cur; }
      else if (items.indexOf(cur) < 0) items.push(cur);       // "1", "2" low ranges
    }
    var at = items.indexOf(cur);
    var maxRpm = d.maxRpm > 0 ? d.maxRpm : 7000;
    var hint = d.gearbox === "manual" && (d.rpm || 0) >= maxRpm * 0.9 && at >= 1 && at < items.length - 1;
    var shift = (d.rpm || 0) >= maxRpm * 0.95, blink = Math.floor(now / 90) % 2;
    var pad = Math.min(W, H) * 0.14, cw = (W - pad * 2) / items.length;
    var ph = Math.min(H - pad * 2, cw * 1.25), pw = Math.min(cw * 0.86, ph);
    var cy = H / 2, fs = ph * 0.62;
    items.forEach(function (g, k) {
      var x = pad + cw * (k + 0.5);
      if (k === at) {
        rr(c, x - pw / 2, cy - ph / 2, pw, ph, Math.min(pw, ph) * 0.3);
        c.fillStyle = shift && blink ? RED : WHITE; c.fill();
        gearText(c, g, x, cy + fs * 0.04, fs * (g.length > 1 ? 0.8 : 1), shift && blink ? WHITE : "#000");
      } else {
        var next = hint && k === at + 1;
        if (next) {
          rr(c, x - pw / 2, cy - ph / 2, pw, ph, Math.min(pw, ph) * 0.3);
          c.strokeStyle = RED; c.lineWidth = 2; c.stroke();
        }
        text(c, g, x, cy + fs * 0.04, font("head", fs * 0.78), next ? RED : g === "R" ? "#5a5a5a" : MUTE);
      }
    });
  });

  // ---- gear: just a box with the gear in it - R, N, 1, 2, 3... -----------
  // Flashes red at the shift point; nothing else on it.
  root.DotGear = make(function (c, W, H, now, d) {
    this.card(c);
    var maxRpm = d.maxRpm > 0 ? d.maxRpm : 7000;
    var shift = (d.rpm || 0) >= maxRpm * 0.95 && Math.floor(now / 90) % 2;
    var S = Math.min(W, H);
    gearText(c, d.gear, W / 2, H / 2 + S * 0.04, S * 0.72, shift ? RED : WHITE);
  });

  // ---- rpm bar: the glyph row on its own, with the rpm in dot digits ------
  root.DotRpm = make(function (c, W, H, now, d) {
    this.card(c);
    var maxRpm = d.maxRpm > 0 ? d.maxRpm : 7000;
    var frac = clamp((d.rpm || 0) / maxRpm, 0, 1);
    var shift = frac >= 0.95, blink = shift && Math.floor(now / 70) % 2;
    var pad = Math.min(W, H) * 0.22;
    var numW = Math.min(W * 0.24, H * 1.9);
    num(c, String(Math.round(d.rpm || 0)), pad + numW, H / 2, H * 0.42, shift ? RED : WHITE, "right");
    var x0 = pad + numW + pad * 0.8, x1 = W - pad, n = 32;
    if (lineGauges()) {
      root.dotGaugeBar(c, x0, x1, H / 2, Math.max(5, H * 0.24), frac, 0.82, shift, blink);
      return;
    }
    var gap = Math.max(2, (x1 - x0) * 0.006), dw = (x1 - x0 - gap * (n - 1)) / n;
    var bh = Math.max(6, H * 0.34), y = H / 2 - bh / 2;
    var lit = Math.round(frac * n), redFrom = Math.floor(n * 0.82);
    for (var i = 0; i < n; i++) {
      var col = DIM;
      if (i < lit) col = shift ? (blink ? RED : "#5a0b0e") : (i >= redFrom ? RED : WHITE);
      else if (i >= redFrom) col = DIMRED;
      rr(c, x0 + i * (dw + gap), y, dw, bh, Math.min(dw, bh) / 2);
      c.fillStyle = col; c.fill();
    }
  });

  // ---- gear ring: the gear in a circle with the revs around it --------------
  // The middle of the main DotDash card, on its own.
  root.DotGearRing = make(function (c, W, H, now, d) {
    var g = this.disc(c), S = g.S, cx = g.cx, cy = g.cy, R = g.R;
    var maxRpm = d.maxRpm > 0 ? d.maxRpm : 7000;
    var frac = clamp((d.rpm || 0) / maxRpm, 0, 1);
    var shift = frac >= 0.95, blink = shift && Math.floor(now / 70) % 2;
    var rr2 = R * 0.82, lw = Math.max(4, S * 0.07);
    root.dotGaugeArc(c, cx, cy, rr2, lw, -Math.PI / 2, Math.PI * 1.5, frac, 0.82, shift, blink);
    if (blink) { c.beginPath(); c.arc(cx, cy, rr2 - lw * 1.2, 0, TAU); c.fillStyle = RED; c.fill(); }
    gearText(c, d.gear, cx, cy + S * 0.03, S * 0.5, WHITE);
  });

  // ---- info: water, oil, fuel --------------------------------------------------
  root.DotInfo = make(function (c, W, H, now, d) {
    this.card(c);
    var rows = [
      ["H2O", d.water, d.waterText || (d.water === undefined ? "--" : Math.round(d.water) + "°"), d.water === undefined ? 0 : (d.water - 50) / 80, d.water > 115],
      ["OIL", d.oil, d.oilText || (d.oil === undefined ? "--" : Math.round(d.oil) + "°"), d.oil === undefined ? 0 : (d.oil - 50) / 100, d.oil > 130],
      ["FUEL", d.fuel, d.fuel === undefined ? "--" : Math.round(d.fuel * 100) + "%", d.fuel || 0, d.fuel !== undefined && d.fuel < 0.15]
    ];
    var pad = Math.min(W, H) * 0.12, rh = (H - pad * 2) / rows.length, fs = Math.min(rh * 0.42, W * 0.08);
    rows.forEach(function (r, i) {
      var y = pad + rh * (i + 0.5);
      text(c, r[0], pad, y, font("mono", fs), MUTE, "left");
      num(c, r[2], W - pad, y, fs * 1.25, r[4] ? RED : WHITE, "right");
      var n = 10, x0 = pad + fs * 3.2, x1 = W - pad - fs * 3.4, s = (x1 - x0) / n;
      var lit = Math.round(clamp(r[3], 0, 1) * n);
      for (var k = 0; k < n; k++) dot(c, x0 + s * (k + 0.5), y, Math.min(s * 0.32, fs * 0.28), k < lit ? (r[4] ? RED : WHITE) : DIM);
    });
  });

  // ---- 0-100 / 0-200 timer ------------------------------------------------------
  root.DotTimer = make(function (c, W, H, now, d) {
    this.card(c);
    var t = this.t, pad = Math.min(W, H) * 0.12;
    var big = t.state === "run" ? (now - t.t0) / 1000 : t.last100;
    var mph = this.mph;
    text(c, mph ? "0-60 MPH" : "0-100 KM/H", pad, pad * 1.1, font("mono", H * 0.11), MUTE, "left", "top");
    text(c, t.state === "run" ? "LIVE" : t.state === "armed" ? "READY" : "", W - pad, pad * 1.1,
         font("mono", H * 0.11), t.state === "run" ? RED : MUTE, "right", "top");
    var best100 = t.state !== "run" && t.last100 !== null && t.last100 === t.best100;
    num(c, big === null || big === undefined ? "--.--" : big.toFixed(2), W / 2, H * 0.52,
        H * 0.34, best100 ? RED : WHITE);
    var line = "BEST " + (t.best100 === null ? "--.--" : t.best100.toFixed(2)) +
               (mph ? "   0-120 " : "   0-200 ") + (t.last200 === null ? "--.--" : t.last200.toFixed(2));
    text(c, line, W / 2, H - pad * 1.1, font("mono", H * 0.095), GREY, "center", "bottom");
  }, function (d, now) {
    // 0-100 / 0-200 km/h, or 0-60 / 0-120 mph when the game is set to mph
    var mph = /mph/i.test(d.speedUnit || "");
    if (mph !== this.mph) { this.mph = mph; this.t = { state: "idle", t0: 0, last100: null, best100: null, last200: null }; }
    var t = this.t, v = (d.speed || 0) * (mph ? 2.23694 : 3.6);
    var a = mph ? 60 : 100, b = mph ? 120 : 200;
    if (v < 0.5) { t.state = "armed"; return; }
    if (t.state === "armed") { t.state = "run"; t.t0 = now; }
    if (t.state === "run" || t.state === "200") {
      var s = (now - t.t0) / 1000;
      if (t.state === "run" && v >= a) {
        t.last100 = s; if (t.best100 === null || s < t.best100) t.best100 = s; t.state = "200";
      }
      if (t.state === "200" && v >= b) { t.last200 = s; t.state = "done"; }
    }
  }, function () { this.t = { state: "idle", t0: 0, last100: null, best100: null, last200: null }; });

  // ---- start / stop button, with the drivetrain controls round it ----------
  // The game sends the drivetrain buttons itself (diff locks, range box, 4WD,
  // hubs, ESC, drive modes, N2O, JATO) through ChangePowerTrainButtons; apps.js
  // keeps them in this.buttons. Each gets a drawn icon in the dash's own style
  // instead of BeamNG's icon font; the full name shows on hover.
  // icon kind + state for each of the game's icons. Text only where text is
  // the clearest sign (N2O, ESC, L / H); everything else is drawn.
  var ICONS = {
    powertrain_differential_open:   ["diffOpen", "off"],
    powertrain_differential_lsd:    ["diffLsd", "mid"],
    powertrain_differential_closed: ["diffLock", "on"],
    powertrain_rangebox_high:       ["text:H", "off"],
    powertrain_rangebox_low:        ["text:L", "on"],
    powertrain_shaft_connected:     ["shaftOn", "on"],
    powertrain_shaft_disconnected:  ["shaftOff", "off"],
    powertrain_wheel_connected:     ["hubOn", "on"],
    powertrain_wheel_disconnected:  ["hubOff", "off"],
    powertrain_esc:                 ["text:ESC", "color"],
    powertrain_n2o:                 ["text:N2O", "ring"],
    powertrain_jato:                ["jato", "ring"]
  };
  function label(b) {
    return ICONS[b.icon] || ["mode", b.color ? "color" : "off"];
  }
  function hex(c2) { return c2 ? "#" + String(c2).replace(/^#/, "") : null; }

  // The drawn icons, in a box of half-size r round (x, y), in colour col.
  function icon(c, kind, x, y, r, col) {
    var lw = Math.max(1.5, r * 0.16);
    c.strokeStyle = col; c.fillStyle = col; c.lineWidth = lw; c.lineCap = "round";
    var line = function (x0, y0, x1, y1) { c.beginPath(); c.moveTo(x + x0 * r, y + y0 * r); c.lineTo(x + x1 * r, y + y1 * r); c.stroke(); };
    var ring = function (rad) { c.beginPath(); c.arc(x, y, rad * r, 0, TAU); c.stroke(); };
    var disc = function (dx, dy, rad) { c.beginPath(); c.arc(x + dx * r, y + dy * r, rad * r, 0, TAU); c.fill(); };
    if (kind.indexOf("diff") === 0) {
      // the differential: a ring gear with the two half shafts
      ring(0.42);
      if (kind === "diffOpen") { line(-0.95, 0, -0.55, 0); line(0.55, 0, 0.95, 0); }
      else if (kind === "diffLsd") { line(-0.95, 0, -0.55, 0); line(0.55, 0, 0.95, 0); disc(0, 0, 0.14); }
      else { line(-0.95, 0, 0.95, 0); disc(0, 0, 0.24); }       // locked: one shaft straight through
    } else if (kind === "shaftOn" || kind === "shaftOff") {
      // a drive shaft between two axles: joined, or with a gap
      line(-0.85, -0.55, -0.85, 0.55); line(0.85, -0.55, 0.85, 0.55);
      if (kind === "shaftOn") line(-0.85, 0, 0.85, 0);
      else { line(-0.85, 0, -0.25, 0); line(0.25, 0, 0.85, 0); }
    } else if (kind === "hubOn" || kind === "hubOff") {
      // a wheel and its hub: locked to the axle, or free
      ring(0.5); disc(0, 0, 0.14);
      if (kind === "hubOn") line(-0.98, 0, -0.5, 0);
      else line(-0.98, 0, -0.7, 0);
    } else if (kind === "jato") {
      // a rocket going right, with its flame
      c.beginPath(); c.moveTo(x + 0.75 * r, y); c.lineTo(x - 0.2 * r, y - 0.38 * r); c.lineTo(x - 0.2 * r, y + 0.38 * r); c.closePath(); c.fill();
      disc(-0.48, 0, 0.13); disc(-0.78, 0, 0.09);
    } else {
      // any other control (drive modes...): a dial of dots with a pointer
      for (var i = 0; i < 6; i++) { var a2 = i / 6 * TAU; disc(Math.cos(a2) * 0.55, Math.sin(a2) * 0.55, 0.09); }
      line(0, 0, 0.32, -0.32);
    }
    c.lineCap = "butt";
  }

  // Text that shrinks until it fits the width it is given.
  function fitText(c, s, x, y, kind, size, maxW, col) {
    c.font = font(kind, size);
    var tw = c.measureText(s).width;
    if (tw > maxW) size = size * maxW / tw;
    text(c, s, x, y, font(kind, size), col);
  }

  // where things are - shared with the click handler in apps.js.
  // The start button keeps one size whatever the car has; the drivetrain
  // buttons go outside it on a half circle to its right, top to bottom, and
  // the app is simply wider to make room.
  root.dotStartLayout = function (W, H, n) {
    var R0 = Math.min(H * 0.44, W * 0.5 - 2);
    var cx = R0 + 2, cy = H / 2;
    var spots = [];
    if (n) {
      var orbit = R0 * 1.34;
      var br0 = R0 * 0.21;
      var half = Math.asin(Math.min(0.95, (H / 2 - br0 - 2) / orbit));     // as tall as the box allows
      var span = Math.min(half * 2, Math.PI * 0.9);
      var step = n > 1 ? span / (n - 1) : 0;
      var br = n > 1 ? Math.min(br0, orbit * Math.sin(step / 2) * 0.9) : br0;
      for (var i = 0; i < n; i++) {
        var ang = n > 1 ? -span / 2 + i * step : 0;
        spots.push({ x: cx + Math.cos(ang) * orbit, y: cy + Math.sin(ang) * orbit, r: br });
      }
    }
    return { S: R0 * 2, cx: cx, cy: cy, R: R0, inner: R0, spots: spots };
  };

  root.DotStartStop = make(function (c, W, H, now, d) {
    var btns = this.buttons || [];
    var L = root.dotStartLayout(W, H, btns.length);
    var cx = L.cx, cy = L.cy, ri = L.inner;
    var on = (d.ignition || 0) > 0, run = !!d.running, press = !!this.pressed;
    var hover = this.hover;

    // the start button: its own disc, always the same size
    c.beginPath(); c.arc(cx, cy, ri, 0, TAU);
    c.fillStyle = CARD; c.fill();
    c.beginPath(); c.arc(cx, cy, ri * 0.82, 0, TAU);
    c.strokeStyle = press ? RED : run ? WHITE : on ? GREY : "#333"; c.lineWidth = Math.max(2, ri * 0.07); c.stroke();
    for (var i = 0; i < 12; i++) {
      var a = -Math.PI / 2 + i / 12 * TAU;
      var lit = run || (press && i === Math.floor(now / 60) % 12);
      dot(c, cx + Math.cos(a) * ri * 0.93, cy + Math.sin(a) * ri * 0.93, Math.max(1.4, ri * 0.032), lit ? (press ? RED : WHITE) : DIM);
    }
    // the hovered control's name takes the place of "ENGINE", shrunk to fit
    var tip = hover !== null && hover !== undefined && btns[hover]
      ? String(btns[hover].tooltip || "").toUpperCase() : "";
    fitText(c, tip || "ENGINE", cx, cy - ri * 0.36, "mono", ri * 0.14, ri * 1.2, tip ? RED : MUTE);
    text(c, "START", cx, cy - ri * 0.02, font("head", ri * 0.27), on || run ? WHITE : GREY);
    text(c, "STOP", cx, cy + ri * 0.27, font("head", ri * 0.27), on || run ? WHITE : GREY);
    dot(c, cx, cy + ri * 0.56, Math.max(2, ri * 0.05), run ? RED : on ? "#5a0b0e" : DIM);

    // the drivetrain buttons, each on its own small disc
    btns.forEach(function (b, k) {
      var p = L.spots[k], m = label(b), kind = m[0], state = m[1], col = hex(b.color);
      var hot = hover === k;
      // every button is dark; engaged ones (diff locked, low range, 4WD, hub
      // locked) get a red ring, half-way ones (LSD) a grey one
      c.beginPath(); c.arc(p.x, p.y, p.r, 0, TAU);
      c.fillStyle = hot ? "rgba(38,38,38,0.92)" : CARD; c.fill();
      var ringCol = state === "on" ? RED : state === "mid" ? GREY : state === "color" && col ? col : "#2e2e2e";
      c.strokeStyle = hot ? WHITE : ringCol; c.lineWidth = Math.max(1.5, p.r * 0.12); c.stroke();
      if (state === "ring" && isFinite(b.ringValue)) {      // tank level for N2O / JATO
        c.beginPath(); c.arc(p.x, p.y, p.r * 0.8, -Math.PI / 2, -Math.PI / 2 + clamp(b.ringValue, 0, 1) * TAU);
        c.strokeStyle = col || WHITE; c.lineWidth = Math.max(1.5, p.r * 0.14); c.stroke();
      }
      var fg = state === "off" ? GREY : WHITE;
      if (kind.indexOf("text:") === 0) {
        var s = kind.slice(5);
        fitText(c, s, p.x, p.y + p.r * 0.04, "mono", p.r * (s.length > 1 ? 0.78 : 1.1), p.r * 1.6, fg);
      } else {
        icon(c, kind, p.x, p.y, p.r * 0.78, fg);
      }
    });
  }, null, function () { this.buttons = []; this.hover = null; });
})(typeof window !== "undefined" ? window : this);

// The BeamNG side for every DotDash widget: one Angular directive per app,
// each with its own canvas, all reading the streams through dotData().
// Angular only hosts the canvas - no bindings, no digest per frame.

function dotApp(directive, Widget, streams, opts) {
  opts = opts || {}
  angular.module('beamng.apps').directive(directive, [function () {
    return {
      // no border, outline or background of our own anywhere: the canvas is the app
      template: '<div style="width:100%; height:100%; position:relative; border:0; outline:none; background:transparent; overflow:hidden;">' +
                '<canvas style="width:100%; height:100%; display:block; border:0; outline:none; background:transparent;"></canvas></div>',
      replace: true,
      restrict: 'EA',
      link: function (scope, element) {
        var root = element[0]
        var w = new Widget(root.querySelector('canvas'))
        StreamsManager.add(streams)
        var ro = window.ResizeObserver ? new ResizeObserver(function () { w.resize() }) : null
        if (ro) ro.observe(root)
        if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { w.resize() })
        if (opts.link) opts.link(root, w, scope)
        scope.$on('streamsUpdate', function (event, s) { w.update(dotData(s)) })
        scope.$on('$destroy', function () {
          StreamsManager.remove(streams)
          if (ro) ro.disconnect()
          if (opts.unlink) opts.unlink(root, w)
        })
      }
    }
  }])
}

// The engine button and the drivetrain buttons round it.
//
// Start/stop: the same calls the stock powertrain app makes - down then up
// toggles the ignition; holding it down cranks the starter, like the key.
//
// Drivetrain: the game's ui_simplePowertrainControl extension sends one
// ChangePowerTrainButtons event per control (diff locks, range box, 4WD, hubs,
// ESC, drive modes, N2O, JATO) once updateButtons() is asked for, and again
// whenever one changes. A click runs the Lua the event came with.
function startStopLink(root, w, scope) {
  var lua = function (s) { bngApi.activeObjectLua(s) }
  var refresh = function () { lua('extensions.ui_simplePowertrainControl.updateButtons()') }
  var redraw = function () { if (w.data) w.draw() }

  scope.$on('ChangePowerTrainButtons', function (event, b) {
    if (!b || !b.id) return
    var i = w.buttons.map(function (x) { return x.id }).indexOf(b.id)
    if (b.remove) { if (i > -1) w.buttons.splice(i, 1) }
    else if (i > -1) w.buttons[i] = Object.assign({}, w.buttons[i], b)
    else w.buttons.push(b)
    redraw()
  })
  var fresh = function () { w.buttons = []; w.hover = null; refresh(); redraw() }
  scope.$on('VehicleChange', fresh)
  scope.$on('VehicleFocusChanged', fresh)
  refresh()

  var at = function (e) {
    var r = root.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top
    var L = dotStartLayout(r.width, r.height, w.buttons.length)
    for (var k = 0; k < L.spots.length; k++) {
      var p = L.spots[k]
      if ((x - p.x) * (x - p.x) + (y - p.y) * (y - p.y) <= p.r * p.r * 1.2) return { button: k }
    }
    if ((x - L.cx) * (x - L.cx) + (y - L.cy) * (y - L.cy) <= L.inner * L.inner) return { start: true }
    return {}
  }
  var press = function (e) {
    var hit = at(e)
    if (hit.button !== undefined) {
      e.preventDefault()
      var b = w.buttons[hit.button]
      if (b && b.onClick) lua(b.onClick)
      setTimeout(refresh, 120)                    // ask for the new state
      return
    }
    if (!hit.start) return
    e.preventDefault()
    w.pressed = true
    lua('electrics.toggleIgnitionLevelOnDown()')
    redraw()
  }
  var release = function () {
    if (!w.pressed) return
    w.pressed = false
    lua('electrics.toggleIgnitionLevelOnUp()')
    redraw()
  }
  var move = function (e) {
    var hit = at(e), h = hit.button !== undefined ? hit.button : null
    root.style.cursor = (h !== null || hit.start) ? 'pointer' : 'default'
    if (h !== w.hover) { w.hover = h; redraw() }
  }
  var leave = function () { release(); if (w.hover !== null) { w.hover = null; redraw() } }
  root.addEventListener('mousedown', press)
  root.addEventListener('mouseup', release)
  root.addEventListener('mousemove', move)
  root.addEventListener('mouseleave', leave)
  w._unbind = function () {
    root.removeEventListener('mousedown', press)
    root.removeEventListener('mouseup', release)
    root.removeEventListener('mousemove', move)
    root.removeEventListener('mouseleave', leave)
  }
}

dotApp("dotGears", DotGears, ["electrics", "engineInfo"])
