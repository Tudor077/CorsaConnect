// font faces, added to the page once
(function(){if(document.getElementById('dotdash-fonts'))return;var s=document.createElement('style');s.id='dotdash-fonts';s.textContent="@font-face{font-family:\"DD Mono\";src:url(/ui/ui-vue/src/assets/fonts/OverpassMono/static/OverpassMono-Regular.ttf) format(\"truetype\");}@font-face{font-family:\"DD Head\";src:url(/ui/ui-vue/src/assets/fonts/Overpass/static/Overpass-SemiBold.ttf) format(\"truetype\");}";document.head.appendChild(s);})();

// Figures in several looks, after phone lock-screen clock faces:
//
//   dot    NDot 55, the dot-matrix font (the original look)
//   grid   digits built from small square tiles, like the tiled clock face
//   block  the same shapes solid and wide, like the big clock face
//   wide   the lock-screen clock face ("520"): very wide, thick bars, thin
//          slits between them, outer corners rounded. Not a 3x5 grid of
//          equal cells - the rows are bar / slit / bar / slit / bar
//   ntype      NType82 Mono - every figure the same width, so live numbers
//              don't shuffle sideways as they change (the default)
//   ntypehead  NType82 Headline, the display face
//   led    the same shapes in big round dots, like the dotted clock face -
//          the NDot feel, but with dots large enough to read at a glance
//
// grid and block are drawn, not typeset: each digit is a 3x5 bitmap of
// strokes, so no font file is needed and they read at any size.
//
// root.DOT_STYLE.digits picks the look for every widget; dotNum() draws.

(function (root) {
  "use strict";

  root.DOT_STYLE = root.DOT_STYLE || { digits: "ntype", gauge: "line" };
  // typeset faces: which font, and how big next to NDot for the same height
  var TYPESET = { dot: ["dot", 1], ntype: ["mono", 1.02], ntypehead: ["head", 1.0] };

  var G = {
    "0": ["111", "101", "101", "101", "111"],
    "1": ["110", "010", "010", "010", "111"],
    "2": ["111", "001", "111", "100", "111"],
    "3": ["111", "001", "111", "001", "111"],
    "4": ["101", "101", "111", "001", "001"],
    "5": ["111", "100", "111", "001", "111"],
    "6": ["111", "100", "111", "101", "111"],
    "7": ["111", "001", "001", "001", "001"],
    "8": ["111", "101", "111", "101", "111"],
    "9": ["111", "101", "111", "001", "111"],
    "-": ["000", "000", "111", "000", "000"],
    ".": ["0", "0", "0", "0", "1"],
    " ": ["0", "0", "0", "0", "0"]
  };

  // the wide face: its own patterns (0 has a slit, not a hole), row heights
  // and column widths, as shares of the digit height
  var WIDE = {
    "0": ["111", "111", "101", "111", "111"],
    "1": ["110", "010", "010", "010", "111"],
    "2": ["111", "001", "111", "100", "111"],
    "3": ["111", "001", "111", "001", "111"],
    "4": ["101", "101", "111", "001", "001"],
    "5": ["111", "100", "111", "001", "111"],
    "6": ["111", "100", "111", "101", "111"],
    "7": ["111", "001", "001", "001", "001"],
    "8": ["111", "101", "111", "101", "111"],
    "9": ["111", "101", "111", "001", "111"],
    "-": ["000", "000", "111", "000", "000"],
    ".": ["0", "0", "0", "0", "1"],
    " ": ["0", "0", "0", "0", "0"]
  };
  var WROWS = [0.3, 0.12, 0.16, 0.12, 0.3];
  var WCOLS = [0.27, 0.62, 0.27];             // a glyph is ~1.16 x its height
  function wideCols(g) { return g[0].length === 1 ? [0.27] : WCOLS; }
  function wideW(g, h) { return wideCols(g).reduce(function (a, b) { return a + b; }, 0) * h; }

  function drawWide(c, s, x0, y, h, col) {
    var gap = h * 0.16, y0 = y - h / 2, rad = h * 0.13;
    c.fillStyle = col;
    for (var i = 0; i < s.length; i++) {
      var g = WIDE[s[i]] || WIDE[" "], cols = wideCols(g);
      var cy = y0;
      for (var r = 0; r < 5; r++) {
        var rh = WROWS[r] * h, cx = x0;
        for (var k = 0; k < cols.length; k++) {
          var cw = cols[k] * h;
          if (g[r][k] === "1") {
            var onp = function (rr2, kk) { return rr2 >= 0 && rr2 < 5 && kk >= 0 && kk < cols.length && g[rr2][kk] === "1"; };
            var tl = !onp(r - 1, k) && !onp(r, k - 1), tr = !onp(r - 1, k) && !onp(r, k + 1);
            var bl = !onp(r + 1, k) && !onp(r, k - 1), br = !onp(r + 1, k) && !onp(r, k + 1);
            var rr = Math.min(rad, rh, cw);
            c.beginPath();
            if (c.roundRect) c.roundRect(cx - 0.3, cy - 0.3, cw + 0.6, rh + 0.6, [tl ? rr : 0, tr ? rr : 0, br ? rr : 0, bl ? rr : 0]);
            else c.rect(cx - 0.3, cy - 0.3, cw + 0.6, rh + 0.6);
            c.fill();
          }
          cx += cw;
        }
        cy += rh;
      }
      x0 += wideW(g, h) + (i < s.length - 1 ? gap : 0);
    }
  }
  function measureWide(s, h) {
    var w = 0;
    for (var i = 0; i < s.length; i++) w += wideW(WIDE[s[i]] || WIDE[" "], h) + (i < s.length - 1 ? h * 0.16 : 0);
    return w;
  }

  // width of one glyph cell, as a share of the digit height
  function cellW(style) { return style === "block" ? 0.3 : 0.26; }
  function on(g, r, k) { return r >= 0 && r < 5 && k >= 0 && k < g[0].length && g[r][k] === "1"; }

  function measure(s, h, style) {
    if (style === "wide") return measureWide(s, h);
    var cw = h / 5 * (cellW(style) * 5), gap = cw * 0.55, w = 0;
    for (var i = 0; i < s.length; i++) {
      var g = G[s[i]] || G[" "];
      w += g[0].length * cw + (i < s.length - 1 ? gap : 0);
    }
    return w;
  }

  function draw(c, s, x, y, h, style, col, align) {
    if (style === "wide") {
      var ww = measureWide(s, h);
      drawWide(c, s, align === "right" ? x - ww : align === "left" ? x : x - ww / 2, y, h, col);
      return;
    }
    var cw = h / 5 * (cellW(style) * 5), ch = h / 5, gap = cw * 0.55;
    var w = measure(s, h, style);
    var x0 = align === "right" ? x - w : align === "left" ? x : x - w / 2;
    var y0 = y - h / 2;
    c.fillStyle = col;
    for (var i = 0; i < s.length; i++) {
      var g = G[s[i]] || G[" "];
      for (var r = 0; r < 5; r++)
        for (var k = 0; k < g[r].length; k++) {
          if (g[r][k] !== "1") continue;
          var cx = x0 + k * cw, cy = y0 + r * ch;
          if (style === "block") {
            // solid: cells overlap a hair so the stroke has no seams; the
            // outer corners of each stroke are rounded, like the clock face
            var rad = Math.min(cw, ch) * 0.32;
            var tl = !on(g, r - 1, k) && !on(g, r, k - 1), tr = !on(g, r - 1, k) && !on(g, r, k + 1);
            var bl = !on(g, r + 1, k) && !on(g, r, k - 1), br = !on(g, r + 1, k) && !on(g, r, k + 1);
            c.beginPath();
            if (c.roundRect) c.roundRect(cx - 0.25, cy - 0.25, cw + 0.5, ch + 0.5, [tl ? rad : 0, tr ? rad : 0, br ? rad : 0, bl ? rad : 0]);
            else c.rect(cx - 0.25, cy - 0.25, cw + 0.5, ch + 0.5);
            c.fill();
          } else if (style === "led") {
            // round dots, 2x2 per stroke cell
            var dr = Math.min(cw, ch) / 4 * 0.86;
            for (var a2 = 0; a2 < 2; a2++)
              for (var b2 = 0; b2 < 2; b2++) {
                c.beginPath(); c.arc(cx + (a2 + 0.5) * cw / 2, cy + (b2 + 0.5) * ch / 2, dr, 0, 6.2832); c.fill();
              }
          } else {
            // tiled: each stroke cell is 2x2 tiles with thin gaps
            var t = Math.max(0.6, Math.min(cw, ch) * 0.07);
            for (var a = 0; a < 2; a++)
              for (var b = 0; b < 2; b++)
                c.fillRect(cx + a * cw / 2 + t / 2, cy + b * ch / 2 + t / 2, cw / 2 - t, ch / 2 - t);
          }
        }
      x0 += g[0].length * cw + gap;
    }
  }

  // size is the font size the caller would have given NDot; digits come out
  // the same height either way, so layouts don't move when the style changes.
  // A trailing unit ("92°", "42%") is set in the mono font after the figures.
  function split(s) {
    var m = /^([0-9.\- ]+)(\D*)$/.exec(s);
    return m ? [m[1], m[2]] : null;
  }
  root.dotNumWidth = function (c, s, size, fontFn) {
    var style = root.DOT_STYLE.digits, p = split(String(s)), ts = TYPESET[style];
    if (ts || !p) { ts = ts || TYPESET.dot; c.font = fontFn(ts[0], size * ts[1]); return c.measureText(String(s)).width; }
    c.font = fontFn("mono", size * 0.5);
    return measure(p[0], size * 0.72, style) + (p[1] ? size * 0.08 + c.measureText(p[1]).width : 0);
  };
  root.dotNum = function (c, s, x, y, size, col, align, fontFn) {
    var style = root.DOT_STYLE.digits;
    s = String(s);
    var p = split(s), ts = TYPESET[style];
    align = align || "center";
    if (ts || !p) {
      ts = ts || TYPESET.dot;
      c.font = fontFn(ts[0], size * ts[1]); c.fillStyle = col;
      c.textAlign = align; c.textBaseline = "middle";
      c.fillText(s, x, y);
      return;
    }
    var h = size * 0.72, w = root.dotNumWidth(c, s, size, fontFn);
    var x0 = align === "right" ? x - w : align === "left" ? x : x - w / 2;
    draw(c, p[0], x0, y, h, style, col, "left");
    if (p[1]) {
      c.font = fontFn("mono", size * 0.5); c.fillStyle = col;
      c.textAlign = "left"; c.textBaseline = "top";
      c.fillText(p[1], x0 + measure(p[0], h, style) + size * 0.08, y - h / 2);
    }
  };
  // the same with a dark outline, for drawing straight over the game
  root.dotNumOutlined = function (c, s, x, y, size, col, align, fontFn, lw) {
    var ts = TYPESET[root.DOT_STYLE.digits];
    if (ts || !split(String(s))) {
      ts = ts || TYPESET.dot;
      c.font = fontFn(ts[0], size * ts[1]); c.textAlign = align || "center"; c.textBaseline = "middle";
      c.lineJoin = "round"; c.lineWidth = lw; c.strokeStyle = "rgba(0,0,0,0.85)";
      c.strokeText(String(s), x, y); c.fillStyle = col; c.fillText(String(s), x, y);
      return;
    }
    var o = lw * 0.45;
    [[-o, 0], [o, 0], [0, -o], [0, o], [-o, -o], [o, o], [-o, o], [o, -o]].forEach(function (d) {
      root.dotNum(c, s, x + d[0], y + d[1], size, "rgba(0,0,0,0.85)", align, fontFn);
    });
    root.dotNum(c, s, x, y, size, col, align, fontFn);
  };

  // ---- rev gauges as one thick continuous line ------------------------------
  // The fill fades in from the start, so the eye goes to where the revs are;
  // a short needle across the line marks the exact point. The redline is a
  // dim red stretch of the track, and turns bright as the revs reach it.
  var RED = "#D71920", TRACK = "#1b1b1b", TRACKRED = "#3a1013";

  // The fade is mixed into the track colour, not drawn with transparency: the
  // arc is many short pieces that overlap a hair, and with alpha every
  // overlap came out darker - a row of little squares along the gauge.
  // Opaque pieces overlap invisibly.
  function mix(c0, c1, t) {
    return "rgb(" + Math.round(c0[0] + (c1[0] - c0[0]) * t) + "," + Math.round(c0[1] + (c1[1] - c0[1]) * t) +
           "," + Math.round(c0[2] + (c1[2] - c0[2]) * t) + ")";
  }
  var T_RGB = [27, 27, 27], W_RGB = [255, 255, 255], R_RGB = [215, 25, 32], G_RGB = [177, 179, 179];
  function fadeCol(f, frac, red, shift, blink) {
    if (shift) return blink ? RED : "#7a0f13";
    var a = 0.16 + 0.84 * Math.pow(frac > 0 ? f / frac : 1, 1.6);   // faint at the start, full at the needle
    return mix(T_RGB, red ? R_RGB : W_RGB, a);
  }

  // Stroke the arc between fractions lo..hi of the sweep a0..a1, coloured by
  // colorAt(f). With createConicGradient it is one stroke and perfectly
  // smooth. Without it, pieces about 2 px long - short arcs at low revs used
  // to get a dozen pieces anyway, and the fade showed as steps.
  function fadeArc(c, cx, cy, rad, lw, a0, a1, lo, hi, colorAt) {
    if (hi - lo < 0.0005) return;
    var sweep = a1 - a0;
    c.lineWidth = lw; c.lineCap = "butt";
    if (c.createConicGradient) {
      var g = c.createConicGradient(a0, cx, cy), n = 24;
      for (var i = 0; i <= n; i++) {
        var f = lo + (hi - lo) * i / n;
        g.addColorStop(Math.min(1, Math.max(0, (f * sweep) / TAU2)), colorAt(f));
      }
      c.beginPath(); c.arc(cx, cy, rad, a0 + sweep * lo, a0 + sweep * hi);
      c.strokeStyle = g; c.stroke();
      return;
    }
    var len = rad * sweep * (hi - lo), m = Math.max(4, Math.ceil(len / 2)), step = (hi - lo) / m;
    for (var k = 0; k < m; k++) {
      // overlap each piece by a fixed pixel: a share of a 2 px piece is less
      // than the anti-aliased edge, and the seams showed as dips
      var f0 = lo + k * step, over = 1.2 / (rad * sweep);
      var f1 = Math.min(hi, f0 + step + over);
      c.beginPath(); c.arc(cx, cy, rad, a0 + sweep * f0, a0 + sweep * f1);
      c.strokeStyle = colorAt(f0 + step / 2); c.stroke();
    }
  }
  var TAU2 = Math.PI * 2;

  root.dotGaugeArc = function (c, cx, cy, rad, lw, a0, a1, frac, redFrom, shift, blink) {
    c.lineCap = "butt"; c.lineWidth = lw;
    c.beginPath(); c.arc(cx, cy, rad, a0, a0 + (a1 - a0) * redFrom); c.strokeStyle = TRACK; c.stroke();
    if (redFrom < 1) { c.beginPath(); c.arc(cx, cy, rad, a0 + (a1 - a0) * redFrom, a1); c.strokeStyle = TRACKRED; c.stroke(); }
    if (frac > 0.002) {
      // white up to the redline, red after it - two strokes, so the change is sharp
      fadeArc(c, cx, cy, rad, lw, a0, a1, 0, Math.min(frac, redFrom),
              function (f) { return fadeCol(f, frac, false, shift, blink); });
      if (frac > redFrom)
        fadeArc(c, cx, cy, rad, lw, a0, a1, redFrom, frac,
                function (f) { return fadeCol(f, frac, true, shift, blink); });
    }
    // the needle: a short bar across the line, only where the revs are
    var a = a0 + (a1 - a0) * frac, ca = Math.cos(a), sa = Math.sin(a);
    var r0 = rad - lw * 1.05, r1 = rad + lw * 1.05;
    c.lineCap = "round";
    c.beginPath(); c.moveTo(cx + ca * r0, cy + sa * r0); c.lineTo(cx + ca * r1, cy + sa * r1);
    c.strokeStyle = "rgba(0,0,0,0.9)"; c.lineWidth = Math.max(4, lw * 0.5); c.stroke();
    c.beginPath(); c.moveTo(cx + ca * r0, cy + sa * r0); c.lineTo(cx + ca * r1, cy + sa * r1);
    c.strokeStyle = shift || frac >= redFrom ? RED : "#ffffff"; c.lineWidth = Math.max(2, lw * 0.26); c.stroke();
    c.lineCap = "butt";
  };

  // like dotGaugeArc, but filled between `from` and `to` (both 0..1 of the
  // sweep) - for the boost gauge, where the fill runs from 0 bar either way
  root.dotGaugeArcFrom = function (c, cx, cy, rad, lw, a0, a1, from, to, redFrom, vacuum, blink, peak) {
    c.lineCap = "butt"; c.lineWidth = lw;
    c.beginPath(); c.arc(cx, cy, rad, a0, a0 + (a1 - a0) * redFrom); c.strokeStyle = TRACK; c.stroke();
    if (redFrom < 1) { c.beginPath(); c.arc(cx, cy, rad, a0 + (a1 - a0) * redFrom, a1); c.strokeStyle = TRACKRED; c.stroke(); }
    var lo = Math.min(from, to), hi = Math.max(from, to), span = hi - lo;
    if (span > 0.002) {
      // fade from the zero point out to the needle
      var fadeAt = function (f) {
        var t = vacuum ? (hi - f) / span : (f - lo) / span;
        return 0.16 + 0.84 * Math.pow(Math.max(0, Math.min(1, t)), 1.6);
      };
      if (vacuum) fadeArc(c, cx, cy, rad, lw, a0, a1, lo, hi, function (f) { return mix(T_RGB, G_RGB, fadeAt(f) * 0.8); });
      else {
        fadeArc(c, cx, cy, rad, lw, a0, a1, lo, Math.min(hi, redFrom), function (f) { return mix(T_RGB, W_RGB, fadeAt(f)); });
        if (hi > redFrom) fadeArc(c, cx, cy, rad, lw, a0, a1, Math.max(lo, redFrom), hi, function (f) { return mix(T_RGB, R_RGB, fadeAt(f)); });
      }
    }
    // zero mark: a thin tick across the track
    var az = a0 + (a1 - a0) * from;
    c.beginPath(); c.moveTo(cx + Math.cos(az) * (rad - lw * 0.7), cy + Math.sin(az) * (rad - lw * 0.7));
    c.lineTo(cx + Math.cos(az) * (rad + lw * 0.7), cy + Math.sin(az) * (rad + lw * 0.7));
    c.strokeStyle = "#555"; c.lineWidth = Math.max(1, lw * 0.12); c.stroke();
    // peak hold: a small red tick
    if (peak !== null && peak !== undefined && peak > from + 0.01) {
      var ap = a0 + (a1 - a0) * peak;
      c.beginPath(); c.moveTo(cx + Math.cos(ap) * (rad - lw * 0.5), cy + Math.sin(ap) * (rad - lw * 0.5));
      c.lineTo(cx + Math.cos(ap) * (rad + lw * 0.5), cy + Math.sin(ap) * (rad + lw * 0.5));
      c.strokeStyle = RED; c.lineWidth = Math.max(1.5, lw * 0.2); c.stroke();
    }
    // the needle
    var an = a0 + (a1 - a0) * to, ca = Math.cos(an), sa = Math.sin(an);
    var r0 = rad - lw * 1.05, r1 = rad + lw * 1.05;
    c.lineCap = "round";
    c.beginPath(); c.moveTo(cx + ca * r0, cy + sa * r0); c.lineTo(cx + ca * r1, cy + sa * r1);
    c.strokeStyle = "rgba(0,0,0,0.9)"; c.lineWidth = Math.max(4, lw * 0.5); c.stroke();
    c.beginPath(); c.moveTo(cx + ca * r0, cy + sa * r0); c.lineTo(cx + ca * r1, cy + sa * r1);
    c.strokeStyle = !vacuum && to >= redFrom ? (blink ? RED : "#ff5a5f") : "#ffffff"; c.lineWidth = Math.max(2, lw * 0.26); c.stroke();
    c.lineCap = "butt";
  };

  root.dotGaugeBar = function (c, x0, x1, y, h, frac, redFrom, shift, blink) {
    var W = x1 - x0, xr = x0 + W * redFrom, xv = x0 + W * frac, r = Math.min(3, h * 0.2);
    var box = function (xa, xb, col) {
      if (xb - xa < 0.5) return;
      c.beginPath();
      if (c.roundRect) c.roundRect(xa, y - h / 2, xb - xa, h, r); else c.rect(xa, y - h / 2, xb - xa, h);
      c.fillStyle = col; c.fill();
    };
    box(x0, xr, TRACK); box(xr, x1, TRACKRED);
    if (frac > 0.002) {
      if (shift) box(x0, xv, blink ? RED : "#7a0f13");
      else {
        var g = c.createLinearGradient(x0, 0, Math.max(x0 + 1, xv), 0);
        g.addColorStop(0, mix(T_RGB, W_RGB, 0.16)); g.addColorStop(1, "#ffffff");
        box(x0, Math.min(xv, xr), g);
        if (xv > xr) {
          var g2 = c.createLinearGradient(xr, 0, Math.max(xr + 1, xv), 0);
          g2.addColorStop(0, mix(T_RGB, R_RGB, 0.55)); g2.addColorStop(1, RED);
          box(xr, xv, g2);
        }
      }
    }
    // the needle: a short upright bar, only where the revs are
    var nh = h * 2.1, nw = Math.max(2, h * 0.22);
    c.fillStyle = "rgba(0,0,0,0.9)"; c.fillRect(xv - nw / 2 - 1.5, y - nh / 2 - 1.5, nw + 3, nh + 3);
    c.fillStyle = shift || frac >= redFrom ? RED : "#ffffff"; c.fillRect(xv - nw / 2, y - nh / 2, nw, nh);
  };
})(typeof window !== "undefined" ? window : this);

// BeamNG streams -> the plain numbers every DotDash widget draws from.
// One place, so the tacho, the boost gauge and the rest can't disagree about
// what "gear" or "fuel" means.

(function (root) {
  "use strict";
  var GEARS_A = ['P', 'R', 'N', 'D', '2', '1'];

  function gearOf(e, info) {
    if (info && info[13] === 'manual') {
      var g = info[5];
      return g > 0 ? String(g) : g < 0 ? 'R' : 'N';
    }
    // electrics.gear is what the gearbox itself calls the gear:
    //   automatic / DCT  "P" "R" "N" "D", "S3" (sport, 3rd), "M4" (manual mode, 4th), "1" "2"
    //   sequential       a plain number (2), 0 for neutral, -1 for reverse
    if (typeof e.gear === 'string' && e.gear.length) return e.gear;
    if (typeof e.gear === 'number' && isFinite(e.gear)) return e.gear > 0 ? String(e.gear) : e.gear < 0 ? 'R' : 'N';
    if (e.gear_A !== undefined) return GEARS_A[Math.round(e.gear_A * 5)] || 'D';
    if (info && info[5] !== undefined) {
      var n = info[5];
      return n > 0 ? String(n) : n < 0 ? 'R' : 'N';
    }
    return 'N';
  }

  // The player picks units in the game's options (km/h or mph, bar / kPa / psi,
  // °C / °F). UiUnits is the game's own converter; without it (the browser
  // preview) we fall back to metric.
  function pconv(kpa) {
    var r = root.UiUnits && UiUnits.pressure ? UiUnits.pressure(kpa) : null;
    return r && isFinite(r.val) ? r : { val: kpa / 100, unit: 'Bar' };
  }
  function tconv(c) {
    var r = root.UiUnits && UiUnits.temperature ? UiUnits.temperature(c) : null;
    return r && isFinite(r.val) ? r : { val: c, unit: '°C' };
  }
  function tempText(c) {
    if (c === undefined || c === null || !isFinite(c)) return undefined;
    var r = tconv(c);
    return Math.round(r.val) + (r.unit === 'K' ? 'K' : '°');
  }
  root.dotPressure = pconv;

  // what each widget subscribes to; boost only when the boost gauge is up
  root.DOT_STREAMS = {
    base: ['electrics', 'engineInfo'],
    g: ['sensors'],
    boost: ['forcedInductionInfo']
  };

  root.dotData = function (s) {
    var e = s.electrics;
    if (!e) return null;
    var info = s.engineInfo;
    var speed = e.wheelspeed !== undefined ? e.wheelspeed : (e.airspeed || 0);

    var text, unit;
    if (root.UiUnits && UiUnits.speed) {
      var u = UiUnits.speed(speed);
      if (u && !isNaN(u.val)) { text = String(Math.round(u.val)); unit = u.unit; }
    }

    var gx = 0, gy = 0;
    if (s.sensors && s.sensors.gravity) {
      var gr = -s.sensors.gravity;
      gx = (s.sensors.gx2 !== undefined ? s.sensors.gx2 : s.sensors.gx || 0) / gr;
      gy = (s.sensors.gy2 !== undefined ? s.sensors.gy2 : s.sensors.gy || 0) / gr;
    }

    var boostKpa, maxBoostKpa;
    var fi = s.forcedInductionInfo;
    if (fi && isFinite(fi.boost) && isFinite(fi.maxBoost)) {
      boostKpa = fi.boost;               // the stream is in kPa whatever the UI shows
      maxBoostKpa = fi.maxBoost;
    }

    var rpm = e.rpmTacho !== undefined ? e.rpmTacho : (e.rpm !== undefined ? e.rpm : (info ? info[4] : 0));
    var idle = info ? info[0] : 800;
    return {
      speed: speed, speedText: text, speedUnit: unit,
      rpm: rpm, maxRpm: info ? info[1] : 0, idleRpm: idle,
      gear: gearOf(e, info),
      // for the gear row: what the box has and where it is
      gearbox: info ? info[13] : undefined,
      gearIndex: info ? info[5] : 0,
      gearsF: info && info[6] > 0 ? info[6] : 0,
      gearsR: info && info[7] > 0 ? info[7] : 0,
      parkingbrake: e.parkingbrake || 0,
      throttle: e.throttle || 0, brake: e.brake || 0, clutch: e.clutch || 0,
      gx: gx, gy: gy,
      water: e.watertemp, oil: e.oiltemp,              // °C, for the warning thresholds
      waterText: tempText(e.watertemp), oilText: tempText(e.oiltemp),
      fuel: info && info[12] ? info[11] / info[12] : undefined,
      abs: !!e.absActive, tcs: !!e.tcsActive,
      handbrake: (e.parkingbrake || 0) > 0.5,
      signalL: !!e.signal_L, signalR: !!e.signal_R,
      highbeam: !!e.highbeam, lowbeam: !!e.lowbeam, fog: (e.fog || 0) > 0,
      lowfuel: !!e.lowfuel,
      ignition: e.ignitionLevel !== undefined ? e.ignitionLevel : (e.ignition ? 2 : 0),
      running: e.engineRunning !== undefined ? !!e.engineRunning : rpm > idle * 0.5,
      boostKpa: boostKpa, maxBoostKpa: maxBoostKpa
    };
  };
})(typeof window !== "undefined" ? window : this);

// DotDash - the renderer. Knows nothing about BeamNG: hand it a canvas, then
// call update(data) with plain numbers whenever new ones arrive. The game
// adapter (app.js) and the browser preview (preview.html) both drive this.
//
// Performance: one 2D canvas, redrawn only when data arrives (the game streams
// at ~30-60 Hz), no DOM churn, no layout. Static parts - the dot grid of the
// G meter - are drawn once into an offscreen canvas and blitted.
//
// data = {
//   speed: m/s, rpm, maxRpm, gear: "N" | "R" | "1".., throttle 0..1, brake 0..1,
//   gx, gy: g (lateral, longitudinal), water, oil: °C, fuel: 0..1,
//   abs, tcs: bool (active), speedText, speedUnit: optional, from the game's units
// }

(function (root) {
  "use strict";

  const WHITE = "#ffffff", RED = "#D71920", DIM = "#262626", MUTE = "#6b6b6b", GREY = "#B1B3B3";
  const RPM_DOTS = 34;
  const TRAIL = 24;

  function DotDash(canvas, opts) {
    this.cv = canvas;
    this.ctx = canvas.getContext("2d");
    this.opts = Object.assign({ fonts: {} }, opts || {});
    this.trail = [];
    this.timer = { state: "idle", t0: 0, best: null, last: null };
    this.peakG = 0;
    this.blink = 0;
    this.data = null;
    this._grid = null;
    this.resize();
  }

  DotDash.prototype.resize = function () {
    const r = this.cv.getBoundingClientRect();
    const dpr = root.devicePixelRatio || 1;
    this.W = Math.max(200, r.width);
    this.H = Math.max(80, r.height);
    this.cv.width = Math.round(this.W * dpr);
    this.cv.height = Math.round(this.H * dpr);
    this.dpr = dpr;
    this._grid = null;                       // geometry changed: rebuild the static layer
    if (this.data) this.draw();
  };

  // ---- the 0-100 km/h timer: arms at a standstill, runs from the first metre
  // 0-100 km/h, or 0-60 mph when the game shows mph
  DotDash.prototype._timer = function (ms, unit, now) {
    const t = this.timer, mph = /mph/i.test(unit || "");
    if (mph !== this.mph) { this.mph = mph; t.state = "idle"; t.best = t.last = null; }
    const v = ms * (mph ? 2.23694 : 3.6), target = mph ? 60 : 100;
    if (v < 0.5) { t.state = "armed"; return; }
    if (t.state === "armed" && v >= 0.5) { t.state = "run"; t.t0 = now; }
    if (t.state === "run" && v >= target) {
      t.last = (now - t.t0) / 1000;
      if (t.best === null || t.last < t.best) t.best = t.last;
      t.state = "done";
    }
  };

  DotDash.prototype.update = function (d) {
    const now = performance.now();
    this._timer(d.speed || 0, d.speedUnit, now);
    this.trail.push([d.gx || 0, d.gy || 0]);
    if (this.trail.length > TRAIL) this.trail.shift();
    this.peakG = Math.max(this.peakG * 0.999, Math.hypot(d.gx || 0, d.gy || 0));
    this.data = d;
    this.draw(now);
  };

  DotDash.prototype._font = function (kind, px) {
    const f = this.opts.fonts;
    const fam = { dot: f.dot || "'NDot 55', 'DD Mono', 'Consolas', monospace",
                  head: f.head || "'NType82 Headline', 'DD Head', 'Segoe UI', sans-serif",
                  mono: f.mono || "'NType82 Mono', 'DD Mono', 'Consolas', monospace" }[kind];
    return `${px}px ${fam}`;
  };

  function rr(c, x, y, w, h, r) {
    c.beginPath();
    c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r);
    c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath();
  }

  // G meter: dots inside a circle, rings at 0.5 g and 1 g - static, cached
  DotDash.prototype._gridLayer = function (cx, cy, R) {
    const g = document.createElement("canvas");
    g.width = this.cv.width; g.height = this.cv.height;
    const c = g.getContext("2d");
    c.scale(this.dpr, this.dpr);
    const step = Math.max(6, R / 7);
    for (let y = -R; y <= R; y += step)
      for (let x = -R; x <= R; x += step)
        if (x * x + y * y <= R * R) {
          c.fillStyle = (Math.abs(x) < 1 || Math.abs(y) < 1) ? "#3a3a3a" : "#1f1f1f";
          c.beginPath(); c.arc(cx + x, cy + y, 1.6, 0, 6.283); c.fill();
        }
    c.strokeStyle = "#2a2a2a"; c.lineWidth = 1;
    for (const k of [0.5, 1]) { c.beginPath(); c.arc(cx, cy, R * k, 0, 6.283); c.stroke(); }
    return g;
  };

  DotDash.prototype.draw = function (now) {
    const d = this.data, c = this.ctx, W = this.W, H = this.H;
    now = now || performance.now();
    c.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    c.clearRect(0, 0, W, H);

    // card
    rr(c, 0, 0, W, H, Math.min(24, H * 0.14));
    c.fillStyle = "rgba(0,0,0,0.84)"; c.fill();

    const P = Math.max(12, H * 0.08);           // padding
    const maxRpm = d.maxRpm > 0 ? d.maxRpm : 7000;
    const frac = Math.min(1, Math.max(0, (d.rpm || 0) / maxRpm));
    const shift = frac >= 0.95;
    this.blink = shift ? (Math.floor(now / 70) % 2) : 0;

    // ---- RPM glyph row ----
    const rowY = P, rowH = Math.max(6, H * 0.055);
    const gap = Math.max(2, W * 0.004);
    const dw = (W - 2 * P - gap * (RPM_DOTS - 1)) / RPM_DOTS;
    const lit = Math.round(frac * RPM_DOTS);
    const redFrom = Math.floor(RPM_DOTS * 0.82);
    if ((root.DOT_STYLE || {}).gauge !== "dots" && root.dotGaugeBar) {
      root.dotGaugeBar(c, P, W - P, rowY + rowH / 2, rowH, frac, 0.82, shift, this.blink);
    } else for (let i = 0; i < RPM_DOTS; i++) {
      const on = i < lit;
      let col = DIM;
      if (on) col = shift ? (this.blink ? RED : "#5a0b0e") : (i >= redFrom ? RED : WHITE);
      else if (i >= redFrom) col = "#2a1112";
      c.fillStyle = col;
      rr(c, P + i * (dw + gap), rowY, dw, rowH, rowH / 2); c.fill();
    }
    c.font = this._font("mono", Math.max(9, H * 0.05));
    c.fillStyle = MUTE; c.textAlign = "left"; c.textBaseline = "top";
    c.fillText("RPM " + Math.round(d.rpm || 0), P, rowY + rowH + 6);
    c.textAlign = "right";
    c.fillText(Math.round(maxRpm / 100) / 10 + "K", W - P, rowY + rowH + 6);
    // 0-100 km/h, centred under the rpm row: runs live, then holds the time;
    // red when it is the best of the session
    const t = this.timer;
    const running = t.state === "run";
    const timeTxt = running ? ((now - t.t0) / 1000).toFixed(1) + "s"
                  : t.last !== null ? t.last.toFixed(2) + "s" : "--.--";
    const isBest = t.best !== null && t.last === t.best && t.state === "done";
    c.textAlign = "center";
    const lbl = (this.mph ? "0-60" : "0-100") + "  ";
    const wl = c.measureText(lbl).width, wt = c.measureText(timeTxt).width;
    const cx0 = W / 2 - (wl + wt) / 2;
    c.textAlign = "left";
    c.fillStyle = MUTE; c.fillText(lbl, cx0, rowY + rowH + 6);
    c.fillStyle = isBest ? RED : running ? WHITE : GREY; c.fillText(timeTxt, cx0 + wl, rowY + rowH + 6);

    // ---- layout below the row ----
    const top = rowY + rowH + H * 0.12;
    const bottomH = H * 0.2;
    const midH = H - top - bottomH - P * 0.6;
    const gR = Math.min(midH / 2, W * 0.13);
    const gCx = W - P - gR, gCy = top + midH / 2;

    // ---- speed, NDot ----
    const kmh = (d.speed || 0) * 3.6;
    const spd = d.speedText !== undefined ? d.speedText : String(Math.round(kmh));
    const sz = midH * 1.02;
    const speedRight = W * 0.42;
    // dim leading zeros, like a real dot display
    const pad = "000".slice(Math.min(3, spd.length));
    if ((root.DOT_STYLE || {}).digits && ["dot"].indexOf(root.DOT_STYLE.digits) < 0 && root.dotNum) {
      const f = (k, px) => this._font(k, px), ym = top + midH * 0.86 - sz * 0.36;
      const wSpd = root.dotNumWidth(c, spd, sz, f), gapW = root.dotNumWidth(c, "00", sz, f) - 2 * root.dotNumWidth(c, "0", sz, f);
      if (pad) root.dotNum(c, pad, speedRight - wSpd + gapW, ym, sz, "#1c1c1c", "right", f);
      root.dotNum(c, spd, speedRight, ym, sz, WHITE, "right", f);
    } else {
      c.font = this._font("dot", sz);
      c.textBaseline = "alphabetic"; c.textAlign = "right";
      const wSpd = c.measureText(spd).width;
      c.fillStyle = "#1c1c1c"; c.fillText(pad, speedRight - wSpd, top + midH * 0.86);
      c.fillStyle = WHITE; c.fillText(spd, speedRight, top + midH * 0.86);
    }
    c.font = this._font("mono", Math.max(9, H * 0.05));
    c.fillStyle = GREY; c.textAlign = "left";
    c.fillText((d.speedUnit || "km/h").toUpperCase(), speedRight + 8, top + midH * 0.86);

    // ---- gear, in a ring that turns red at the shift point ----
    const gx0 = speedRight + (gCx - gR - speedRight) / 2 + 10, gy0 = gCy;
    const ringR = Math.min(midH * 0.5, (gCx - gR - speedRight) * 0.32);
    c.beginPath(); c.arc(gx0, gy0, ringR, 0, 6.283);
    c.fillStyle = shift && this.blink ? RED : "#111"; c.fill();
    c.strokeStyle = shift ? RED : "#333"; c.lineWidth = 2; c.stroke();
    // rpm progress around the ring
    c.beginPath(); c.arc(gx0, gy0, ringR + 5, -Math.PI / 2, -Math.PI / 2 + frac * 6.283);
    c.strokeStyle = frac >= 0.82 ? RED : WHITE; c.lineWidth = 2.5; c.stroke();
    const g = d.gear === undefined ? "N" : String(d.gear), m = /^([SM])(\d+)$/.exec(g);
    c.textAlign = "center"; c.textBaseline = "middle";
    if (m) {   // "S3" / "M4": the number big, the mode letter small beside it
      c.font = this._font("head", ringR * 1.05); const wn = c.measureText(m[2]).width;
      c.fillStyle = WHITE; c.fillText(m[2], gx0 + ringR * 0.12, gy0 + ringR * 0.06);
      c.font = this._font("mono", ringR * 0.42);
      c.fillStyle = m[1] === "S" ? RED : GREY; c.fillText(m[1], gx0 + ringR * 0.12 - wn / 2 - ringR * 0.22, gy0 - ringR * 0.22);
    } else {
      c.font = this._font("head", ringR * (g.length > 1 ? 0.85 : 1.15));
      c.fillStyle = WHITE; c.fillText(g, gx0, gy0 + ringR * 0.06);
    }

    // ---- G meter ----
    if (!this._grid) this._grid = this._gridLayer(gCx, gCy, gR);
    c.setTransform(1, 0, 0, 1, 0, 0);
    c.drawImage(this._grid, 0, 0);
    c.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    const GMAX = 1.5;
    const toXY = (p) => [gCx + Math.max(-1, Math.min(1, p[0] / GMAX)) * gR,
                         gCy - Math.max(-1, Math.min(1, p[1] / GMAX)) * gR];
    this.trail.forEach((p, i) => {
      const [x, y] = toXY(p);
      c.globalAlpha = (i + 1) / this.trail.length * 0.6;
      c.fillStyle = WHITE; c.beginPath(); c.arc(x, y, 1.8, 0, 6.283); c.fill();
    });
    c.globalAlpha = 1;
    const [px, py] = toXY([d.gx || 0, d.gy || 0]);
    c.fillStyle = RED; c.beginPath(); c.arc(px, py, Math.max(4, gR * 0.08), 0, 6.283); c.fill();
    c.font = this._font("mono", Math.max(9, H * 0.05));
    c.textBaseline = "middle";
    const gLineY = H - P - (H * 0.2) * 0.55;
    c.fillStyle = WHITE; c.textAlign = "right";
    c.fillText(Math.hypot(d.gx || 0, d.gy || 0).toFixed(2) + "G", gCx + gR, gLineY);
    c.fillStyle = MUTE; c.textAlign = "left";
    c.fillText("PK " + this.peakG.toFixed(2), gCx - gR, gLineY);

    // ---- bottom strip: pedals as dot bars, then the readouts ----
    const by = H - P - bottomH * 0.55;
    const fs = Math.max(9, H * 0.052);
    c.font = this._font("mono", fs); c.textBaseline = "middle";
    const bar = (x, label, v, col) => {
      c.fillStyle = MUTE; c.textAlign = "left"; c.fillText(label, x, by);
      const n = 8, s = fs * 0.62, x0 = x + c.measureText(label + " ").width;
      for (let i = 0; i < n; i++) {
        c.fillStyle = i < Math.round(v * n) ? col : DIM;
        c.beginPath(); c.arc(x0 + i * (s + 2) + s / 2, by, s / 2, 0, 6.283); c.fill();
      }
      return x0 + n * (s + 2) + fs;
    };
    let x = P;
    x = bar(x, "THR", d.throttle || 0, WHITE);
    x = bar(x, "BRK", d.brake || 0, RED);

    const items = [];
    if (d.water !== undefined) items.push(["H2O", d.waterText || Math.round(d.water) + "°", d.water > 115]);
    if (d.oil !== undefined) items.push(["OIL", d.oilText || Math.round(d.oil) + "°", d.oil > 130]);
    if (d.fuel !== undefined) items.push(["FUEL", Math.round(d.fuel * 100) + "%", d.fuel < 0.1]);
    if (d.abs) items.push(["ABS", "", true]);
    if (d.tcs) items.push(["TCS", "", true]);
    // stop short of the G meter's column - its readouts live under it
    const limit = gCx - gR - fs;
    for (const [label, val, warn, best] of items) {
      const w = c.measureText(label + " " + val).width;
      if (x + w > limit) break;
      c.fillStyle = MUTE; c.textAlign = "left"; c.fillText(label, x, by);
      x += c.measureText(label + " ").width;
      c.fillStyle = warn ? RED : best ? RED : WHITE;
      c.fillText(val, x, by);
      x += c.measureText(val).width + fs * 1.2;
    }
  };

  root.DotDash = DotDash;
})(typeof window !== "undefined" ? window : this);

// The BeamNG side for every DotDash widget: one Angular directive per app,
// each with its own canvas, all reading the streams through dotData().
// Angular only hosts the canvas - no bindings, no digest per frame.

function dotApp(directive, Widget, streams, opts) {
  opts = opts || {}
  angular.module('beamng.apps').directive(directive, [function () {
    return {
      // no border, outline or background of our own anywhere: the canvas is the app
      template: '<div style="width:100%; height:100%; position:relative; border:0; outline:none; background:transparent; overflow:hidden;">' +
                '<canvas style="width:100%; height:100%; display:block; border:0; outline:none; background:transparent;"></canvas></div>',
      replace: true,
      restrict: 'EA',
      link: function (scope, element) {
        var root = element[0]
        var w = new Widget(root.querySelector('canvas'))
        StreamsManager.add(streams)
        var ro = window.ResizeObserver ? new ResizeObserver(function () { w.resize() }) : null
        if (ro) ro.observe(root)
        if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { w.resize() })
        if (opts.link) opts.link(root, w, scope)
        scope.$on('streamsUpdate', function (event, s) { w.update(dotData(s)) })
        scope.$on('$destroy', function () {
          StreamsManager.remove(streams)
          if (ro) ro.disconnect()
          if (opts.unlink) opts.unlink(root, w)
        })
      }
    }
  }])
}

// The engine button and the drivetrain buttons round it.
//
// Start/stop: the same calls the stock powertrain app makes - down then up
// toggles the ignition; holding it down cranks the starter, like the key.
//
// Drivetrain: the game's ui_simplePowertrainControl extension sends one
// ChangePowerTrainButtons event per control (diff locks, range box, 4WD, hubs,
// ESC, drive modes, N2O, JATO) once updateButtons() is asked for, and again
// whenever one changes. A click runs the Lua the event came with.
function startStopLink(root, w, scope) {
  var lua = function (s) { bngApi.activeObjectLua(s) }
  var refresh = function () { lua('extensions.ui_simplePowertrainControl.updateButtons()') }
  var redraw = function () { if (w.data) w.draw() }

  scope.$on('ChangePowerTrainButtons', function (event, b) {
    if (!b || !b.id) return
    var i = w.buttons.map(function (x) { return x.id }).indexOf(b.id)
    if (b.remove) { if (i > -1) w.buttons.splice(i, 1) }
    else if (i > -1) w.buttons[i] = Object.assign({}, w.buttons[i], b)
    else w.buttons.push(b)
    redraw()
  })
  var fresh = function () { w.buttons = []; w.hover = null; refresh(); redraw() }
  scope.$on('VehicleChange', fresh)
  scope.$on('VehicleFocusChanged', fresh)
  refresh()

  var at = function (e) {
    var r = root.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top
    var L = dotStartLayout(r.width, r.height, w.buttons.length)
    for (var k = 0; k < L.spots.length; k++) {
      var p = L.spots[k]
      if ((x - p.x) * (x - p.x) + (y - p.y) * (y - p.y) <= p.r * p.r * 1.2) return { button: k }
    }
    if ((x - L.cx) * (x - L.cx) + (y - L.cy) * (y - L.cy) <= L.inner * L.inner) return { start: true }
    return {}
  }
  var press = function (e) {
    var hit = at(e)
    if (hit.button !== undefined) {
      e.preventDefault()
      var b = w.buttons[hit.button]
      if (b && b.onClick) lua(b.onClick)
      setTimeout(refresh, 120)                    // ask for the new state
      return
    }
    if (!hit.start) return
    e.preventDefault()
    w.pressed = true
    lua('electrics.toggleIgnitionLevelOnDown()')
    redraw()
  }
  var release = function () {
    if (!w.pressed) return
    w.pressed = false
    lua('electrics.toggleIgnitionLevelOnUp()')
    redraw()
  }
  var move = function (e) {
    var hit = at(e), h = hit.button !== undefined ? hit.button : null
    root.style.cursor = (h !== null || hit.start) ? 'pointer' : 'default'
    if (h !== w.hover) { w.hover = h; redraw() }
  }
  var leave = function () { release(); if (w.hover !== null) { w.hover = null; redraw() } }
  root.addEventListener('mousedown', press)
  root.addEventListener('mouseup', release)
  root.addEventListener('mousemove', move)
  root.addEventListener('mouseleave', leave)
  w._unbind = function () {
    root.removeEventListener('mousedown', press)
    root.removeEventListener('mouseup', release)
    root.removeEventListener('mousemove', move)
    root.removeEventListener('mouseleave', leave)
  }
}

dotApp("dotDash", DotDash, ["electrics", "engineInfo", "sensors"])
